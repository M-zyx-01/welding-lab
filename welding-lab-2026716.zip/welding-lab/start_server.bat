@echo off
cd /d "E:\??\welding-lab"
"C:\Users\40821\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe" -c "import sys; sys.path.insert(0, 'E:\??\welding-lab'); from backend.main import app; import uvicorn; uvicorn.run(app, host='0.0.0.0', port=8765)"
pause
