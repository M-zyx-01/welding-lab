@echo off
echo ============================================
echo   Welding Intelligence Lab
echo   Server starting on http://localhost:8765
echo ============================================
echo.
cd /d "%~dp0"
python -m uvicorn backend.main:app --host 0.0.0.0 --port 8765
pause
