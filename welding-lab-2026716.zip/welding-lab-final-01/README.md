# 焊接智能分析实验室 - Welding Intelligence Lab

多物理场焊接智能分析平台 / Multi-Physics Welding Intelligence Platform

## 快速开始 Quick Start

### 方式一：双击 HTML 文件（推荐，无需安装）
直接双击 `welding_lab_standalone.html` 即可在浏览器中使用，无需服务器。

### 方式二：启动本地服务器
```bash
pip install -r requirements.txt
python -m uvicorn backend.main:app --host 0.0.0.0 --port 8765
```
或双击 `start_server.bat`，然后访问 http://localhost:8765

## 功能模块 Features

| 模块 | 中文 | 功能 |
|------|------|------|
| 材料 Material | 碳当量、可焊性、焊材兼容 | CE/IW, weldability CSI, filler compatibility |
| 热学 Thermal | 热输入、Rosenthal 2D/3D、t8/5、HAZ | Heat input, temperature field, cooling time |
| 力学 Stress | 残余应力、强度预测、变形 | Residual stress, strength, deformation |
| 流体 Fluid | Marangoni、熔池几何、浮力 | Pool geometry, buoyancy effects |
| 电磁 EM | 洛伦兹力、磁偏吹、电磁搅拌 | Lorentz force, arc blow, EM stirring |
| 环境 Env | 15种服役环境、腐蚀、HIC、疲劳 | 15 environments, corrosion, fatigue life |

## 材料数据库 Materials

- 母材 Base Materials: 35+ 种（碳钢、不锈钢、铝合金、镍合金、钛合金、铜合金、镁合金、锆合金、高熵合金、增材制造合金等）
- 焊材 Filler Metals: 24 种（碳钢焊丝/焊条、不锈钢焊丝、镍基焊丝、铝合金焊丝、钛合金焊丝、铜合金焊丝、药芯焊丝）

## 服役环境 Environments (15种)

室内标准、室内受控、沿海大气、海水浸没、飞溅区、极寒、沙漠干旱、高温氧化、深冷、核辐照、酸性服役(H2S)、深海、化工酸性、地热、太空真空

## 项目结构

```
welding-lab-final/
├── welding_lab_standalone.html   # 独立运行版（双击打开）
├── frontend/                     # 前端源码
│   ├── index.html
│   ├── css/style.css
│   └── js/app.js
├── backend/                      # 后端源码
│   ├── main.py                   # FastAPI 入口
│   ├── data/
│   │   ├── material_db.py        # 材料数据库 (72种)
│   │   └── weld_data.py          # 焊接数据结构
│   ├── models/                   # 物理模型
│   │   ├── material.py
│   │   ├── thermal.py
│   │   ├── mechanical.py
│   │   ├── fluid.py
│   │   ├── electromagnetic.py
│   │   └── environmental.py
│   └── analysis/                 # 分析引擎
│       ├── predictor.py
│       ├── inference.py
│       ├── sensitivity.py
│       ├── comparison.py
│       ├── report.py
│       ├── energy.py
│       ├── statistics.py
│       ├── conclusion.py
│       ├── experiment.py
│       └── storage.py
├── requirements.txt
├── start_server.bat
└── README.md
```
