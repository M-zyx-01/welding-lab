"""Statistical analysis: Pearson correlation, trend detection, IQR outliers, distribution analysis, group comparison."""
import math
from typing import List, Dict, Any

def pearson_correlation(x: List[float], y: List[float]) -> dict:
    """Pearson correlation coefficient between two variables."""
    n = len(x)
    if n != len(y) or n < 3:
        return {"error": "Need at least 3 paired data points"}
    mx = sum(x) / n
    my = sum(y) / n
    sx = math.sqrt(sum((v - mx) ** 2 for v in x) / (n - 1))
    sy = math.sqrt(sum((v - my) ** 2 for v in y) / (n - 1))
    if sx < 1e-15 or sy < 1e-15:
        return {"pearson_r": 0.0, "p_value": 1.0, "significance": "Not significant (zero variance)", "strength": "None"}
    r = sum((x[i] - mx) * (y[i] - my) for i in range(n)) / ((n - 1) * sx * sy)
    r = max(-1.0, min(1.0, r))
    t_stat = r * math.sqrt((n - 2) / (1 - r * r)) if abs(r) < 1.0 else float("inf")
    df = n - 2
    p_value = _approx_p_value(t_stat, df) if t_stat != float("inf") else 0.0
    abs_r = abs(r)
    if abs_r >= 0.8: strength = "Very Strong"
    elif abs_r >= 0.6: strength = "Strong"
    elif abs_r >= 0.4: strength = "Moderate"
    elif abs_r >= 0.2: strength = "Weak"
    else: strength = "Very Weak"
    sig = "Significant (p < 0.05)" if p_value < 0.05 else "Not significant (p >= 0.05)"
    return {"pearson_r": round(r, 4), "p_value": round(p_value, 4), "significance": sig, "strength": strength,
            "sample_size": n, "interpretation": f"{strength} {('positive' if r > 0 else 'negative')} correlation"}

def _approx_p_value(t: float, df: int) -> float:
    """Simple approximation of t-distribution p-value."""
    if t < 0: t = -t
    z = t * (1.0 - 1.0 / (4.0 * df))
    p = 1.0 / (1.0 + math.exp(-1.7 * z))
    return 2.0 * (1.0 - p)

def trend_detection(x: List[float], y: List[float]) -> dict:
    """Detect monotonic trend using Spearman rank correlation."""
    n = len(x)
    if n < 5:
        return {"error": "Need at least 5 data points"}
    rx = _rank(x)
    ry = _rank(y)
    d2 = sum((rx[i] - ry[i]) ** 2 for i in range(n))
    rho = 1.0 - (6.0 * d2) / (n * (n ** 2 - 1.0))
    if rho > 0.7: trend = "Strong increasing"
    elif rho > 0.3: trend = "Weak increasing"
    elif rho > -0.3: trend = "No clear trend"
    elif rho > -0.7: trend = "Weak decreasing"
    else: trend = "Strong decreasing"
    return {"spearman_rho": round(rho, 4), "trend": trend,
            "interpretation": f"Monotonic trend: {trend} (rho={rho:.3f})"}

def _rank(data: List[float]) -> List[float]:
    pairs = sorted(enumerate(data), key=lambda p: p[1])
    ranks = [0.0] * len(data)
    i = 0
    while i < len(pairs):
        j = i
        while j < len(pairs) and pairs[j][1] == pairs[i][1]:
            j += 1
        avg = (i + j + 1) / 2.0
        for k in range(i, j):
            ranks[pairs[k][0]] = avg
        i = j
    return ranks

def iqr_outlier_detection(values: List[float]) -> dict:
    """Detect outliers using IQR method (Tukey fences)."""
    n = len(values)
    if n < 4:
        return {"error": "Need at least 4 data points"}
    sv = sorted(values)
    q1 = sv[n // 4]
    q3 = sv[3 * n // 4]
    iqr = q3 - q1
    lower = q1 - 1.5 * iqr
    upper = q3 + 1.5 * iqr
    outliers = [v for v in values if v < lower or v > upper]
    return {"q1": round(q1, 4), "q3": round(q3, 4), "iqr": round(iqr, 4),
            "lower_fence": round(lower, 4), "upper_fence": round(upper, 4),
            "outlier_count": len(outliers), "outliers": [round(v, 4) for v in outliers],
            "outlier_pct": round(len(outliers) / n * 100, 1)}

def distribution_analysis(values: List[float]) -> dict:
    """Basic distribution statistics: mean, median, std, skewness, kurtosis."""
    n = len(values)
    if n < 3:
        return {"error": "Need at least 3 data points"}
    mean = sum(values) / n
    sv = sorted(values)
    median = sv[n // 2] if n % 2 == 1 else (sv[n // 2 - 1] + sv[n // 2]) / 2.0
    variance = sum((v - mean) ** 2 for v in values) / (n - 1)
    std = math.sqrt(variance)
    skew = sum((v - mean) ** 3 for v in values) / ((n - 1) * std ** 3) if std > 0 else 0
    kurt = sum((v - mean) ** 4 for v in values) / ((n - 1) * std ** 4) - 3.0 if std > 0 else 0
    cv = std / mean * 100 if mean != 0 else 0
    range_val = sv[-1] - sv[0]
    return {"count": n, "mean": round(mean, 4), "median": round(median, 4),
            "std_dev": round(std, 4), "variance": round(variance, 4),
            "skewness": round(skew, 4), "kurtosis": round(kurt, 4),
            "cv_pct": round(cv, 1), "range": round(range_val, 4),
            "min": round(sv[0], 4), "max": round(sv[-1], 4)}

def group_comparison(groups: Dict[str, List[float]]) -> dict:
    """Compare multiple groups: means, ANOVA-like F-statistic, effect size."""
    if len(groups) < 2:
        return {"error": "Need at least 2 groups"}
    stats = {}
    all_vals = []
    for name, vals in groups.items():
        if len(vals) < 2:
            return {"error": f"Group {name} needs at least 2 values"}
        m = sum(vals) / len(vals)
        stats[name] = {"mean": round(m, 4), "std": round(math.sqrt(sum((v - m) ** 2 for v in vals) / (len(vals) - 1)), 4) if len(vals) > 1 else 0,
                        "count": len(vals), "min": round(min(vals), 4), "max": round(max(vals), 4)}
        all_vals.extend(vals)
    grand_mean = sum(all_vals) / len(all_vals)
    ss_between = sum(len(vals) * (stats[name]["mean"] - grand_mean) ** 2 for name, vals in groups.items())
    ss_within = sum(sum((v - stats[name]["mean"]) ** 2 for v in vals) for name, vals in groups.items())
    k = len(groups)
    n_total = len(all_vals)
    df_between = k - 1
    df_within = n_total - k
    msb = ss_between / df_between if df_between > 0 else 0
    msw = ss_within / df_within if df_within > 0 else 1
    f_stat = msb / msw if msw > 0 else 0
    means = [stats[name]["mean"] for name in groups]
    rng = max(means) - min(means)
    pooled_sd = math.sqrt(msw)
    cohens_f = (rng / pooled_sd) if pooled_sd > 0 else 0
    if cohens_f >= 0.4: effect = "Large"
    elif cohens_f >= 0.25: effect = "Medium"
    elif cohens_f >= 0.1: effect = "Small"
    else: effect = "Negligible"
    return {"groups": stats, "overall_mean": round(grand_mean, 4),
            "f_statistic": round(f_stat, 4), "cohens_f": round(cohens_f, 4),
            "effect_size": effect, "total_n": n_total}
