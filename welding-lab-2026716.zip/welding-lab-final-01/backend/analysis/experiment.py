"""Experiment management: SQLite CRUD + CSV import/export."""
import sqlite3, csv, io, os, json
from datetime import datetime
from typing import List, Dict, Optional

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "outputs", "experiments.db")

def _get_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    return conn

def init_db():
    conn = _get_db()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS experiments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            material TEXT,
            filler TEXT,
            process TEXT,
            current REAL,
            voltage REAL,
            travel_speed REAL,
            plate_thickness REAL,
            preheat_temp REAL,
            environment TEXT,
            joint_type TEXT,
            position TEXT,
            quality_score REAL,
            quality_grade TEXT,
            overall_risk TEXT,
            heat_input REAL,
            haz_width REAL,
            residual_stress REAL,
            corrosion_rate REAL,
            service_life REAL,
            notes TEXT,
            full_result TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_exp_material ON experiments(material)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_exp_env ON experiments(environment)")
    conn.commit()
    conn.close()

def create_experiment(data: Dict) -> dict:
    init_db()
    params = data.get("parameters", {})
    joint = data.get("joint", {})
    quality = data.get("quality", {})
    summary = data.get("summary", {})
    conn = _get_db()
    cur = conn.execute("""
        INSERT INTO experiments (name, material, filler, process, current, voltage, travel_speed,
            plate_thickness, preheat_temp, environment, joint_type, position,
            quality_score, quality_grade, overall_risk, heat_input, haz_width,
            residual_stress, corrosion_rate, service_life, notes, full_result)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    """, (
        data.get("name", data.get("id", f"Exp-{datetime.now().strftime('%m%d-%H%M')}")),
        data.get("material", data.get("base_material_key", "")),
        data.get("filler", data.get("filler_material_key", "")),
        params.get("process", ""),
        params.get("current"), params.get("voltage"), params.get("travel_speed"),
        joint.get("plate_thickness"), params.get("preheat_temp"),
        data.get("environment", ""), joint.get("joint_type", ""), joint.get("position", ""),
        quality.get("quality_score"), quality.get("grade"),
        summary.get("overall_risk"),
        summary.get("heat_input_kJ_per_mm"), summary.get("haz_width_mm"),
        summary.get("residual_stress_MPa"), summary.get("corrosion_rate_mm_per_yr"),
        summary.get("service_life_years"), data.get("notes", ""),
        json.dumps(data, ensure_ascii=False)
    ))
    eid = cur.lastrowid
    conn.commit()
    conn.close()
    return {"id": eid, "created": True}

def list_experiments(limit: int = 100, offset: int = 0, material: str = None, environment: str = None) -> dict:
    init_db()
    conn = _get_db()
    where = []
    params = []
    if material:
        where.append("material LIKE ?")
        params.append(f"%{material}%")
    if environment:
        where.append("environment = ?")
        params.append(environment)
    where_clause = ("WHERE " + " AND ".join(where)) if where else ""
    count_row = conn.execute(f"SELECT COUNT(*) as cnt FROM experiments {where_clause}", params).fetchone()
    total = count_row["cnt"] if count_row else 0
    rows = conn.execute(
        f"SELECT id, name, material, process, environment, quality_score, quality_grade, overall_risk, created_at FROM experiments {where_clause} ORDER BY created_at DESC LIMIT ? OFFSET ?",
        params + [limit, offset]
    ).fetchall()
    conn.close()
    return {
        "total": total,
        "limit": limit, "offset": offset,
        "experiments": [dict(r) for r in rows]
    }

def get_experiment(exp_id: int) -> dict:
    init_db()
    conn = _get_db()
    row = conn.execute("SELECT * FROM experiments WHERE id = ?", (exp_id,)).fetchone()
    conn.close()
    if not row:
        return {"error": f"Experiment {exp_id} not found"}
    result = dict(row)
    if result.get("full_result"):
        try:
            result["full_result"] = json.loads(result["full_result"])
        except:
            pass
    return result

def update_experiment(exp_id: int, data: Dict) -> dict:
    init_db()
    fields = []
    values = []
    for key in ["name", "material", "filler", "process", "environment", "notes"]:
        if key in data:
            fields.append(f"{key} = ?")
            values.append(data[key])
    if fields:
        fields.append("updated_at = CURRENT_TIMESTAMP")
        values.append(exp_id)
        conn = _get_db()
        conn.execute(f"UPDATE experiments SET {', '.join(fields)} WHERE id = ?", values)
        conn.commit()
        conn.close()
    return {"id": exp_id, "updated": True}

def delete_experiment(exp_id: int) -> dict:
    init_db()
    conn = _get_db()
    cur = conn.execute("DELETE FROM experiments WHERE id = ?", (exp_id,))
    conn.commit()
    conn.close()
    return {"id": exp_id, "deleted": cur.rowcount > 0}

def import_csv(csv_data: str) -> dict:
    reader = csv.DictReader(io.StringIO(csv_data))
    count = 0
    errors = []
    for row in reader:
        try:
            data = {
                "name": row.get("name", f"CSV-{count+1}"),
                "material": row.get("material", row.get("base_material", "")),
                "parameters": {
                    "process": row.get("process", "GTAW"),
                    "current": float(row.get("current", 150)),
                    "voltage": float(row.get("voltage", 20)),
                    "travel_speed": float(row.get("travel_speed", 2.0)),
                    "preheat_temp": float(row.get("preheat_temp", 25)),
                },
                "joint": {
                    "joint_type": row.get("joint_type", "butt"),
                    "plate_thickness": float(row.get("plate_thickness", 10)),
                    "position": row.get("position", "1G"),
                },
                "environment": row.get("environment", "indoor_standard"),
                "notes": row.get("notes", "")
            }
            create_experiment(data)
            count += 1
        except Exception as e:
            errors.append({"row": count + 1, "error": str(e)})
    return {"imported": count, "errors": errors}

def export_csv(limit: int = 1000) -> str:
    init_db()
    conn = _get_db()
    rows = conn.execute("SELECT * FROM experiments ORDER BY created_at DESC LIMIT ?", (limit,)).fetchall()
    conn.close()
    if not rows:
        return "No experiments found"
    output = io.StringIO()
    fieldnames = ["id","name","material","filler","process","current","voltage","travel_speed",
                  "plate_thickness","preheat_temp","environment","joint_type","position",
                  "quality_score","quality_grade","overall_risk","heat_input","haz_width",
                  "residual_stress","corrosion_rate","service_life","notes","created_at"]
    writer = csv.DictWriter(output, fieldnames=fieldnames, extrasaction='ignore')
    writer.writeheader()
    for row in rows:
        writer.writerow(dict(row))
    return output.getvalue()

def get_statistics() -> dict:
    init_db()
    conn = _get_db()
    stats = {}
    stats["total"] = conn.execute("SELECT COUNT(*) as c FROM experiments").fetchone()["c"]
    if stats["total"] > 0:
        stats["avg_quality"] = round(conn.execute("SELECT AVG(quality_score) as a FROM experiments").fetchone()["a"] or 0, 1)
        grades = conn.execute("SELECT quality_grade, COUNT(*) as c FROM experiments GROUP BY quality_grade ORDER BY c DESC").fetchall()
        stats["grade_distribution"] = {g["quality_grade"]: g["c"] for g in grades}
        risks = conn.execute("SELECT overall_risk, COUNT(*) as c FROM experiments GROUP BY overall_risk ORDER BY c DESC").fetchall()
        stats["risk_distribution"] = {r["overall_risk"]: r["c"] for r in risks}
        top = conn.execute("SELECT material, COUNT(*) as c FROM experiments GROUP BY material ORDER BY c DESC LIMIT 5").fetchall()
        stats["top_materials"] = {t["material"]: t["c"] for t in top}
    conn.close()
    return stats
