"""Energy analysis: power density, energy efficiency, energy balance, spatial distribution."""
import math
from ..data.weld_data import WeldParameters, MaterialSpec

def power_density(params: WeldParameters) -> dict:
    """Calculate arc power density and energy distribution."""
    power = params.voltage * params.current
    if params.electrode_diameter and params.electrode_diameter > 0:
        area = math.pi * (params.electrode_diameter / 2.0) ** 2
        pd = power / area
    else:
        area = math.pi * (params.arc_length / 2.0) ** 2
        pd = power / area if area > 0 else 0
    return {
        "arc_power_W": round(power, 1),
        "power_density_W_per_mm2": round(pd, 1),
        "effective_area_mm2": round(area, 2)
    }

def energy_efficiency(params: WeldParameters, mat: MaterialSpec, thickness: float) -> dict:
    """Calculate energy efficiency: how much arc energy actually melts material."""
    Q_arc = params.voltage * params.current
    v_ms = params.travel_speed / 1000.0
    Q_net = params.arc_efficiency * Q_arc
    energy_per_length = Q_net / v_ms if v_ms > 0 else 0
    rho = mat.density
    Cp = mat.specific_heat
    Tm = mat.melting_point
    T0 = params.preheat_temp
    Hf = 2.7e5
    E_theoretical = rho * Cp * (Tm - T0) + rho * Hf
    w_m = 0.004
    d_m = thickness / 1000.0
    E_melt_theoretical = E_theoretical * w_m * d_m
    melt_efficiency = (E_melt_theoretical / energy_per_length * 100) if energy_per_length > 0 else 0
    melt_efficiency = min(melt_efficiency, 95.0)
    heat_loss_radiation = Q_net * 0.08
    heat_loss_convection = Q_net * 0.12
    heat_loss_conduction = Q_net * (1.0 - 0.08 - 0.12 - params.arc_efficiency * 0.25)
    useful_energy = Q_net * params.arc_efficiency * 0.75
    return {
        "total_arc_power_W": round(Q_arc, 1),
        "net_energy_per_length_J_per_m": round(energy_per_length, 0),
        "melt_efficiency_pct": round(melt_efficiency, 1),
        "theoretical_melting_energy_J_per_m3": round(E_theoretical, 0),
        "useful_energy_W": round(useful_energy, 1),
        "loss_radiation_W": round(heat_loss_radiation, 1),
        "loss_convection_W": round(heat_loss_convection, 1),
        "loss_conduction_W": round(heat_loss_conduction, 1)
    }

def energy_balance(params: WeldParameters, mat: MaterialSpec, thickness: float) -> dict:
    """Full energy balance: input -> losses -> melting -> HAZ -> base."""
    Q_net = params.arc_efficiency * params.voltage * params.current
    E_melt = Q_net * 0.35
    E_haz = Q_net * 0.30
    E_base = Q_net * 0.15
    E_loss = Q_net - E_melt - E_haz - E_base
    return {
        "net_heat_input_W": round(Q_net, 1),
        "energy_melting_pct": 35.0,
        "energy_haz_pct": 30.0,
        "energy_base_pct": 15.0,
        "energy_loss_pct": round(E_loss / Q_net * 100, 1) if Q_net > 0 else 0,
        "energy_melting_W": round(E_melt, 1),
        "energy_haz_W": round(E_haz, 1),
        "energy_base_W": round(E_base, 1),
        "energy_loss_W": round(E_loss, 1)
    }

def spatial_distribution(params: WeldParameters, mat: MaterialSpec) -> list:
    """Energy spatial distribution from arc center outward (Gaussian approximation)."""
    if params.electrode_diameter and params.electrode_diameter > 0:
        sigma = params.electrode_diameter / 2.0 / 2.354
    else:
        sigma = params.arc_length / 2.0 / 2.354
    sigma = max(sigma, 0.5)
    Q_total = params.arc_efficiency * params.voltage * params.current
    Q_peak = Q_total / (2.0 * math.pi * sigma ** 2)
    results = []
    for r_mm in [0.0, 1.0, 2.0, 3.0, 5.0, 8.0, 12.0, 20.0]:
        q_r = Q_peak * math.exp(- (r_mm ** 2) / (2.0 * sigma ** 2))
        results.append({
            "distance_from_center_mm": r_mm,
            "energy_flux_W_per_mm2": round(q_r, 1),
            "normalized_intensity_pct": round(q_r / Q_peak * 100, 1) if Q_peak > 0 else 0
        })
    return {
        "gaussian_sigma_mm": round(sigma, 2),
        "peak_flux_W_per_mm2": round(Q_peak, 1),
        "distribution": results
    }
