"""Conclusion engine: generates research conclusions from batch experimental data."""
from typing import List, Dict, Any
from .statistics import pearson_correlation, distribution_analysis, group_comparison

def generate_conclusions(batch_results: List[Dict], context: Dict = None) -> dict:
    """Generate structured research conclusions from batch experimental data."""
    if not batch_results or len(batch_results) < 2:
        return {"error": "Need at least 2 batch results for conclusion generation"}

    context = context or {}
    conclusions = []

    metrics = _extract_metrics(batch_results)
    quality_scores = metrics.get("quality_score", [])
    heat_inputs = metrics.get("heat_input_kJ_per_mm", [])
    haz_widths = metrics.get("haz_width_mm", [])
    residual_stresses = metrics.get("residual_stress_MPa", [])
    corrosion_rates = metrics.get("corrosion_rate_mm_per_yr", [])
    service_lives = metrics.get("service_life_years", [])

    # 1. Parameter- Quality relationships
    if len(heat_inputs) >= 3 and len(quality_scores) >= 3:
        corr_hi_q = pearson_correlation(heat_inputs, quality_scores)
        if abs(corr_hi_q.get("pearson_r", 0)) > 0.4:
            direction = "positively" if corr_hi_q["pearson_r"] > 0 else "negatively"
            conclusions.append({
                "category": "Process-Quality",
                "finding": f"Heat input {direction} correlates with weld quality score (r={corr_hi_q['pearson_r']:.3f}, p={corr_hi_q['p_value']:.3f}).",
                "confidence": "High" if abs(corr_hi_q["pearson_r"]) > 0.7 else "Moderate",
                "implication": "Optimize heat input within the tested range for best quality.",
                "type": "correlation"
            })

    # 2. Optimal parameter range
    if quality_scores and len(quality_scores) >= 3:
        best_idx = quality_scores.index(max(quality_scores))
        best_entry = batch_results[best_idx] if best_idx < len(batch_results) else {}
        conclusions.append({
            "category": "Optimal Conditions",
            "finding": f"Best quality score ({max(quality_scores)}) achieved with "
                       f"material={best_entry.get('material', '?')}, "
                       f"process={best_entry.get('process', '?')}.",
            "confidence": "Moderate",
            "implication": "Use these parameters as baseline for further optimization.",
            "type": "optimum"
        })

    # 3. Material-environment compatibility
    mat_env_groups = _group_by(batch_results, "material", "environment")
    recommendations = []
    for key, entries in mat_env_groups.items():
        risks = [e.get("overall_risk", "") for e in entries]
        high_risks = [r for r in risks if r in ("High", "Critical", "Severe")]
        if len(high_risks) > len(entries) * 0.5:
            mat, env = key.split("|") if "|" in key else ("?", "?")
            recommendations.append(f"Avoid {mat} in {env} environment (>50% high-risk results)")
            conclusions.append({
                "category": "Material-Environment",
                "finding": f"High risk prevalence ({len(high_risks)}/{len(entries)}) for {mat} in {env}.",
                "confidence": "High",
                "implication": f"Consider alternative material for {env} service.",
                "type": "risk"
            })

    # 4. Statistical summary
    if quality_scores:
        dist = distribution_analysis(quality_scores)
        quality_conclusion = {
            "category": "Overall Quality",
            "finding": f"Mean quality score: {dist['mean']:.1f} ({'above' if dist['mean'] > 70 else 'below'} acceptable threshold). Variability (CV): {dist['cv_pct']:.1f}%.",
            "confidence": "High",
            "implication": "Process is stable" if dist['cv_pct'] < 15 else "Process shows significant variability - investigate sources",
            "type": "summary"
        }
        conclusions.append(quality_conclusion)

    # 5. Safety recommendations
    if conclusions:
        safety_recs = _generate_safety_recommendations(batch_results)
        recommendations.extend(safety_recs)

    # 6. Future research directions
    future = _generate_future_directions(batch_results, metrics, conclusions)

    return {
        "conclusions": conclusions,
        "recommendations": recommendations,
        "future_directions": future,
        "summary": _generate_summary_text(conclusions, recommendations),
        "sample_size": len(batch_results)
    }

def _extract_metrics(batch_results: List[Dict]) -> Dict[str, List]:
    """Extract numeric metrics from batch results."""
    metrics = {}
    for entry in batch_results:
        if isinstance(entry.get("quality"), dict):
            metrics.setdefault("quality_score", []).append(entry["quality"].get("quality_score", 0))
        elif "quality_score" in entry:
            metrics.setdefault("quality_score", []).append(entry.get("quality_score", 0))
        if "summary" in entry:
            s = entry["summary"]
            for key in ["heat_input_kJ_per_mm", "haz_width_mm", "residual_stress_MPa",
                        "corrosion_rate_mm_per_yr", "service_life_years"]:
                if key in s and s[key] is not None:
                    metrics.setdefault(key, []).append(float(s[key]))
    return metrics

def _group_by(data: List[Dict], key1: str, key2: str = None) -> Dict[str, List]:
    groups = {}
    for entry in data:
        k = entry.get(key1, "?")
        if key2:
            k += "|" + str(entry.get(key2, "?"))
        groups.setdefault(k, []).append(entry)
    return groups

def _generate_safety_recommendations(batch_results: List[Dict]) -> List[str]:
    recs = []
    high_risk = [e for e in batch_results if str(e.get("overall_risk", "")).lower() in ("high", "critical", "severe")]
    if len(high_risk) > len(batch_results) * 0.3:
        recs.append(f"WARNING: {len(high_risk)}/{len(batch_results)} scenarios show high risk. Mandatory pre-production testing required.")
    env_risks = set()
    for e in high_risk:
        env_risks.add(e.get("environment", "?"))
    if env_risks:
        recs.append(f"High-risk environments identified: {', '.join(sorted(env_risks))}. Apply additional safety factors.")
    return recs

def _generate_future_directions(batch_results: List[Dict], metrics: Dict, conclusions: List[Dict]) -> List[str]:
    directions = []
    if metrics.get("quality_score", []) and len(set(metrics["quality_score"])) > 1:
        directions.append("Perform full-factorial DOE to map parameter interactions")
    materials = set(e.get("material", "") for e in batch_results)
    if len(materials) < 3:
        directions.append("Expand material testing matrix to include alternative alloys and grades")
    envs = set(e.get("environment", "") for e in batch_results)
    if len(envs) < 4:
        directions.append("Extend environmental testing to cover more service conditions")
    directions.append("Validate conclusions with physical weld trials and destructive testing")
    return directions

def _generate_summary_text(conclusions: List[Dict], recommendations: List[str]) -> str:
    parts = []
    for c in conclusions[:3]:
        parts.append(f"[{c['category']}] {c['finding']}")
    if recommendations:
        parts.append(f"Key recommendation: {recommendations[0]}")
    return " | ".join(parts)
