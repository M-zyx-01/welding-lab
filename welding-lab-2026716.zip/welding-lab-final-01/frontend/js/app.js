// Welding Intelligence Lab - Frontend Application
const API = "/api";

var FALLBACK_MATERIALS = {
    "Q345": {name: "Q345 (16Mn) Low-Alloy Steel", grade: "Q345", category: "carbon_steel", yield_strength_MPa: 345},
    "Q235": {name: "Q235 Carbon Steel", grade: "Q235", category: "carbon_steel", yield_strength_MPa: 235},
    "Q460": {name: "Q460 High-Strength Low-Alloy Steel", grade: "Q460", category: "carbon_steel", yield_strength_MPa: 460},
    "Q690": {name: "Q690 Quenched & Tempered Steel", grade: "Q690", category: "carbon_steel", yield_strength_MPa: 690},
    "A36": {name: "ASTM A36 Carbon Steel", grade: "A36", category: "carbon_steel", yield_strength_MPa: 250},
    "S355": {name: "S355 Structural Steel (EN 10025)", grade: "S355", category: "carbon_steel", yield_strength_MPa: 355},
    "EH36": {name: "EH36 Shipbuilding Steel", grade: "EH36", category: "carbon_steel", yield_strength_MPa: 355},
    "A516-Gr70": {name: "A516 Grade 70 Pressure Vessel Steel", grade: "A516 Gr70", category: "carbon_steel", yield_strength_MPa: 260},
    "API-X65": {name: "API 5L X65 Pipeline Steel", grade: "X65", category: "carbon_steel", yield_strength_MPa: 450},
    "API-X80": {name: "API 5L X80 Pipeline Steel", grade: "X80", category: "carbon_steel", yield_strength_MPa: 555},
    "9Cr-1Mo": {name: "9Cr-1Mo Creep-Resistant Steel (P91)", grade: "P91", category: "carbon_steel", yield_strength_MPa: 415},
    "304": {name: "AISI 304 Stainless Steel", grade: "304", category: "stainless_steel", yield_strength_MPa: 205},
    "316L": {name: "AISI 316L Stainless Steel", grade: "316L", category: "stainless_steel", yield_strength_MPa: 290},
    "309S": {name: "AISI 309S Stainless Steel (Heat-Resistant)", grade: "309S", category: "stainless_steel", yield_strength_MPa: 260},
    "310S": {name: "AISI 310S Stainless Steel (High-Temp)", grade: "310S", category: "stainless_steel", yield_strength_MPa: 275},
    "321": {name: "AISI 321 Stainless Steel (Ti-Stabilized)", grade: "321", category: "stainless_steel", yield_strength_MPa: 240},
    "347": {name: "AISI 347 Stainless Steel (Nb-Stabilized)", grade: "347", category: "stainless_steel", yield_strength_MPa: 240},
    "2205": {name: "2205 Duplex Stainless Steel", grade: "2205", category: "stainless_steel", yield_strength_MPa: 450},
    "2507": {name: "2507 Super Duplex Stainless Steel", grade: "2507", category: "stainless_steel", yield_strength_MPa: 550},
    "17-4PH": {name: "17-4PH Precipitation Hardening SS", grade: "17-4PH", category: "stainless_steel", yield_strength_MPa: 1000},
    "904L": {name: "904L Super Austenitic Stainless Steel", grade: "904L", category: "stainless_steel", yield_strength_MPa: 300},
    "Inconel 625": {name: "Inconel 625", grade: "Inconel 625", category: "nickel", yield_strength_MPa: 450},
    "Inconel 718": {name: "Inconel 718", grade: "Inconel 718", category: "nickel", yield_strength_MPa: 1034},
    "Monel 400": {name: "Monel 400 (Ni-Cu Alloy)", grade: "Monel 400", category: "nickel", yield_strength_MPa: 240},
    "Hastelloy C-276": {name: "Hastelloy C-276", grade: "C-276", category: "nickel", yield_strength_MPa: 355},
    "6061-T6": {name: "AA 6061-T6 Aluminium", grade: "6061-T6", category: "aluminium", yield_strength_MPa: 276},
    "2024-T3": {name: "AA 2024-T3 Aluminium (Aerospace)", grade: "2024-T3", category: "aluminium", yield_strength_MPa: 345},
    "5083": {name: "AA 5083 Aluminium (Marine Grade)", grade: "5083", category: "aluminium", yield_strength_MPa: 240},
    "7075-T6": {name: "AA 7075-T6 Aluminium", grade: "7075-T6", category: "aluminium", yield_strength_MPa: 503},
    "Ti-6Al-4V": {name: "Ti-6Al-4V (Grade 5)", grade: "Ti-6Al-4V", category: "titanium", yield_strength_MPa: 880},
    "Ti-Grade2": {name: "Titanium Grade 2 (CP)", grade: "Grade 2", category: "titanium", yield_strength_MPa: 345},
    "C11000": {name: "C11000 ETP Copper", grade: "C11000", category: "copper", yield_strength_MPa: 110},
    "Cu-Ni-90-10": {name: "Cu-Ni 90/10 (C70600)", grade: "C70600", category: "copper", yield_strength_MPa: 150},
    "AZ31B": {name: "AZ31B Magnesium Alloy", grade: "AZ31B", category: "magnesium", yield_strength_MPa: 170},
    "Zircaloy-4": {name: "Zircaloy-4 (Nuclear Cladding)", grade: "Zry-4", category: "zirconium", yield_strength_MPa: 380},
};

var FALLBACK_ENVIRONMENTS = [
    {key: "indoor_standard", name: "Indoor Standard", name_cn: "室内标准", description: "Standard indoor, 20-25C"},
    {key: "indoor_controlled", name: "Indoor Controlled", name_cn: "室内受控", description: "Cleanroom, 20C, low humidity"},
    {key: "coastal_atmosphere", name: "Coastal Atmosphere", name_cn: "沿海大气", description: "Salt spray, high humidity"},
    {key: "marine_immersed", name: "Marine Immersed", name_cn: "海水浸没", description: "Seawater immersion, high Cl-"},
    {key: "marine_splash", name: "Marine Splash Zone", name_cn: "飞溅区", description: "Wet/dry cycling, highest corrosion"},
    {key: "arctic_cold", name: "Arctic Cold", name_cn: "极寒", description: "-60 to -20C, embrittlement risk"},
    {key: "desert_arid", name: "Desert Arid", name_cn: "沙漠干旱", description: "Hot dry, large temp swings"},
    {key: "high_temp_oxidation", name: "High Temp Oxidation", name_cn: "高温氧化", description: ">500C, oxidation risk"},
    {key: "cryogenic", name: "Cryogenic", name_cn: "深冷", description: "<-100C, LNG/LH2 storage"},
    {key: "nuclear_radiation", name: "Nuclear Radiation", name_cn: "核辐照", description: "Radiation exposure"},
    {key: "sour_service", name: "Sour Service", name_cn: "酸性服役", description: "H2S, SSC risk per NACE MR0175"},
    {key: "subsea_deepwater", name: "Subsea Deepwater", name_cn: "深海", description: ">1000m, high pressure"},
    {key: "chemical_acid", name: "Chemical Acid", name_cn: "化工酸性", description: "H2SO4/HCl exposure"},
    {key: "geothermal", name: "Geothermal", name_cn: "地热", description: "Hot brine, corrosion+erosion"},
    {key: "space_vacuum", name: "Space Vacuum", name_cn: "太空真空", description: "Vacuum, thermal cycling"},
];

function populateMaterials(data) {
    var selBase = document.getElementById("sel-base-mat");
    var selFiller = document.getElementById("sel-filler-mat");
    while (selBase.options.length > 1) selBase.remove(1);
    while (selFiller.options.length > 1) selFiller.remove(1);
    var catOrder = {carbon_steel:1, low_alloy_steel:1, stainless_steel:2, aluminium:3, nickel:4, titanium:5, copper:6, magnesium:7, zirconium:8, cobalt:9, tool_steel:10};
    var sorted = Object.entries(data).sort(function(a, b) {
        return (catOrder[a[1].category] || 99) - (catOrder[b[1].category] || 99);
    });
    sorted.forEach(function(entry) {
        var key = entry[0], mat = entry[1];
        var ymp = mat.yield_strength_MPa || 0;
        var label = mat.name + (mat.grade ? " (" + mat.grade + ")" : "") + " - " + ymp + " MPa";
        var opt = document.createElement("option");
        opt.value = key;
        opt.textContent = label;
        selBase.appendChild(opt);
        selFiller.appendChild(opt.cloneNode(true));
    });
}

function populateEnvironments(envs) {
    var sel = document.getElementById("sel-environment");
    while (sel.options.length > 1) sel.remove(1);
    envs.forEach(function(env) {
        var opt = document.createElement("option");
        opt.value = env.key;
        opt.textContent = (env.name_cn || env.name) + " / " + env.name;
        opt.title = env.description || "";
        sel.appendChild(opt);
    });
}


// Fallback material data when API is unavailable
var FALLBACK_MATERIALS = {
    "Q345": {name: "Q345 (16Mn) Low-Alloy Steel", grade: "Q345", category: "carbon_steel", yield_strength_MPa: 345},
    "Q235": {name: "Q235 Carbon Steel", grade: "Q235", category: "carbon_steel", yield_strength_MPa: 235},
    "Q460": {name: "Q460 High-Strength Low-Alloy Steel", grade: "Q460", category: "carbon_steel", yield_strength_MPa: 460},
    "Q690": {name: "Q690 Quenched & Tempered Steel", grade: "Q690", category: "carbon_steel", yield_strength_MPa: 690},
    "A36": {name: "ASTM A36 Carbon Steel", grade: "A36", category: "carbon_steel", yield_strength_MPa: 250},
    "S355": {name: "S355 Structural Steel (EN 10025)", grade: "S355", category: "carbon_steel", yield_strength_MPa: 355},
    "EH36": {name: "EH36 Shipbuilding Steel", grade: "EH36", category: "carbon_steel", yield_strength_MPa: 355},
    "DH36": {name: "DH36 Shipbuilding Steel (Low-Temp)", grade: "DH36", category: "carbon_steel", yield_strength_MPa: 355},
    "A516-Gr70": {name: "A516 Grade 70 Pressure Vessel Steel", grade: "A516 Gr70", category: "carbon_steel", yield_strength_MPa: 260},
    "API-X65": {name: "API 5L X65 Pipeline Steel", grade: "X65", category: "carbon_steel", yield_strength_MPa: 450},
    "API-X80": {name: "API 5L X80 Pipeline Steel", grade: "X80", category: "carbon_steel", yield_strength_MPa: 555},
    "API-X100": {name: "API 5L X100 Ultra-High Strength Pipeline Steel", grade: "X100", category: "carbon_steel", yield_strength_MPa: 690},
    "9Cr-1Mo": {name: "9Cr-1Mo Creep-Resistant Steel (P91)", grade: "P91", category: "carbon_steel", yield_strength_MPa: 415},
    "304": {name: "AISI 304 Stainless Steel", grade: "304", category: "stainless_steel", yield_strength_MPa: 205},
    "316L": {name: "AISI 316L Stainless Steel", grade: "316L", category: "stainless_steel", yield_strength_MPa: 290},
    "309S": {name: "AISI 309S Stainless Steel (Heat-Resistant)", grade: "309S", category: "stainless_steel", yield_strength_MPa: 260},
    "310S": {name: "AISI 310S Stainless Steel (High-Temp)", grade: "310S", category: "stainless_steel", yield_strength_MPa: 275},
    "321": {name: "AISI 321 Stainless Steel (Ti-Stabilized)", grade: "321", category: "stainless_steel", yield_strength_MPa: 240},
    "347": {name: "AISI 347 Stainless Steel (Nb-Stabilized)", grade: "347", category: "stainless_steel", yield_strength_MPa: 240},
    "2205": {name: "2205 Duplex Stainless Steel", grade: "2205", category: "stainless_steel", yield_strength_MPa: 450},
    "2507": {name: "2507 Super Duplex Stainless Steel", grade: "2507", category: "stainless_steel", yield_strength_MPa: 550},
    "17-4PH": {name: "17-4PH Precipitation Hardening SS", grade: "17-4PH", category: "stainless_steel", yield_strength_MPa: 1000},
    "904L": {name: "904L Super Austenitic Stainless Steel", grade: "904L", category: "stainless_steel", yield_strength_MPa: 300},
    "254SMO": {name: "254SMO Super Austenitic Stainless Steel", grade: "254SMO", category: "stainless_steel", yield_strength_MPa: 350},
    "Inconel 625": {name: "Inconel 625", grade: "Inconel 625", category: "nickel", yield_strength_MPa: 450},
    "Inconel 718": {name: "Inconel 718", grade: "Inconel 718", category: "nickel", yield_strength_MPa: 1034},
    "Monel 400": {name: "Monel 400 (Ni-Cu Alloy)", grade: "Monel 400", category: "nickel", yield_strength_MPa: 240},
    "Incoloy 825": {name: "Incoloy 825 (Ni-Fe-Cr-Mo)", grade: "Incoloy 825", category: "nickel", yield_strength_MPa: 310},
    "Hastelloy C-276": {name: "Hastelloy C-276", grade: "C-276", category: "nickel", yield_strength_MPa: 355},
    "6061-T6": {name: "AA 6061-T6 Aluminium", grade: "6061-T6", category: "aluminium", yield_strength_MPa: 276},
    "2024-T3": {name: "AA 2024-T3 Aluminium (Aerospace)", grade: "2024-T3", category: "aluminium", yield_strength_MPa: 345},
    "5083": {name: "AA 5083 Aluminium (Marine Grade)", grade: "5083", category: "aluminium", yield_strength_MPa: 240},
    "7075-T6": {name: "AA 7075-T6 Aluminium", grade: "7075-T6", category: "aluminium", yield_strength_MPa: 503},
    "Ti-6Al-4V": {name: "Ti-6Al-4V (Grade 5)", grade: "Ti-6Al-4V", category: "titanium", yield_strength_MPa: 880},
    "Ti-Grade2": {name: "Titanium Grade 2 (CP)", grade: "Grade 2", category: "titanium", yield_strength_MPa: 345},
    "C11000": {name: "C11000 ETP Copper", grade: "C11000", category: "copper", yield_strength_MPa: 110},
    "Cu-Ni-90-10": {name: "Cu-Ni 90/10 (C70600)", grade: "C70600", category: "copper", yield_strength_MPa: 150},
    "Cu-Ni-70-30": {name: "Cu-Ni 70/30 (C71500)", grade: "C71500", category: "copper", yield_strength_MPa: 170},
    "AZ31B": {name: "AZ31B Magnesium Alloy (Wrought)", grade: "AZ31B", category: "magnesium", yield_strength_MPa: 170},
    "Zircaloy-4": {name: "Zircaloy-4 (Nuclear Cladding)", grade: "Zry-4", category: "zirconium", yield_strength_MPa: 380},
    "Stellite 6": {name: "Stellite 6 (Co-Cr-W Hardfacing)", grade: "Stellite 6", category: "cobalt", yield_strength_MPa: 650},
    "H13": {name: "H13 Hot Work Tool Steel", grade: "H13", category: "tool_steel", yield_strength_MPa: 1500},
    "P20": {name: "P20 Mold Steel (Pre-Hardened)", grade: "P20", category: "tool_steel", yield_strength_MPa: 850},
};

var FALLBACK_ENVIRONMENTS = [
    {key: "indoor_standard", name: "Indoor Standard", name_cn: "室内标准环境", description: "Standard indoor environment, 20-25C, moderate humidity"},
    {key: "indoor_controlled", name: "Indoor Controlled", name_cn: "室内受控环境", description: "Controlled cleanroom, 20C, low humidity"},
    {key: "coastal_atmosphere", name: "Coastal Atmosphere", name_cn: "沿海大气环境", description: "Coastal zone with salt spray and high humidity"},
    {key: "marine_immersed", name: "Marine Immersed", name_cn: "海水浸没环境", description: "Fully immersed in seawater, high chloride"},
    {key: "marine_splash", name: "Marine Splash Zone", name_cn: "飞溅区环境", description: "Alternating wet/dry, highest corrosion rate zone"},
    {key: "arctic_cold", name: "Arctic Cold", name_cn: "极寒环境", description: "Extreme cold -60 to -20C, low-temperature embrittlement risk"},
    {key: "desert_arid", name: "Desert Arid", name_cn: "沙漠干旱环境", description: "Hot dry desert, large diurnal temperature swings"},
    {key: "high_temp_oxidation", name: "High Temperature Oxidation", name_cn: "高温氧化环境", description: "Elevated temperature >500C, oxidation/carburization risk"},
    {key: "cryogenic", name: "Cryogenic", name_cn: "深冷环境", description: "Cryogenic temperatures <-100C, LNG/LH2 storage"},
    {key: "nuclear_radiation", name: "Nuclear Radiation", name_cn: "核辐照环境", description: "Radiation exposure, irradiation embrittlement"},
    {key: "sour_service", name: "Sour Service (H2S)", name_cn: "酸性服役(H2S)", description: "H2S containing environment, SSC risk per NACE MR0175"},
    {key: "subsea_deepwater", name: "Subsea Deepwater", name_cn: "深海环境", description: "Deep water >1000m, high hydrostatic pressure, low temp"},
    {key: "chemical_acid", name: "Chemical Acid Environment", name_cn: "化工酸性环境", description: "Acidic chemical processing, H2SO4/HCl exposure"},
    {key: "geothermal", name: "Geothermal", name_cn: "地热环境", description: "High temp geothermal brine, combined corrosion+erosion"},
    {key: "space_vacuum", name: "Space Vacuum", name_cn: "太空真空环境", description: "Vacuum, extreme thermal cycling, atomic oxygen"},
];

function populateMaterials(data) {
    var mats = data;
    var selBase = document.getElementById("sel-base-mat");
    var selFiller = document.getElementById("sel-filler-mat");
    // Clear existing options except first
    while (selBase.options.length > 1) selBase.remove(1);
    while (selFiller.options.length > 1) selFiller.remove(1);
    
    var sorted = Object.entries(mats).sort(function(a, b) {
        var catOrder = {carbon_steel:1, low_alloy_steel:1, stainless_steel:2, aluminium:3, nickel:4, titanium:5, copper:6, magnesium:7, zirconium:8, cobalt:9, tool_steel:10};
        return (catOrder[a[1].category] || 99) - (catOrder[b[1].category] || 99);
    });
    sorted.forEach(function(entry) {
        var key = entry[0], mat = entry[1];
        var ymp = mat.yield_strength_MPa || 0;
        var label = mat.name + (mat.grade ? " (" + mat.grade + ")" : "") + " - " + ymp + " MPa";
        var opt = document.createElement("option");
        opt.value = key;
        opt.textContent = label;
        selBase.appendChild(opt);
        selFiller.appendChild(opt.cloneNode(true));
    });
}

function populateEnvironments(envs) {
    var sel = document.getElementById("sel-environment");
    while (sel.options.length > 1) sel.remove(1);
    envs.forEach(function(env) {
        var opt = document.createElement("option");
        opt.value = env.key;
        opt.textContent = (env.name_cn || env.name) + " / " + env.name;
        opt.title = env.description || "";
        sel.appendChild(opt);
    });
}

let currentResults = null, currentInference = null;
let currentLang = "zh";
let peakTempChart = null, sensitivityChart = null;
let compareScenarios = [];

function setLang(lang) {
  currentLang = lang;
  document.querySelectorAll(".lang-btn").forEach(function(b) { b.classList.toggle("active", b.dataset.lang === lang); });
  document.getElementById("toolbar-subtitle").textContent =
    lang === "zh" ? "多物理场焊接智能分析平台" : "Multi-Physics Welding Intelligence Platform";
}

document.addEventListener("DOMContentLoaded", function() {
  loadMaterials();
  loadEnvironments();
  setupTabs();
  setupLangToggle();
  setupProcessDefaults();
  setupFeatureClick();
});

function setupLangToggle() {
  document.querySelectorAll(".lang-btn").forEach(function(btn) {
    btn.addEventListener("click", function() { setLang(btn.dataset.lang); });
  });
}

function setupFeatureClick() {
  document.querySelectorAll(".feature[data-nav]").forEach(function(f) {
    f.addEventListener("click", function() {
      var tabId = f.dataset.nav;
      if (!currentResults && !currentInference) {
        showFeatureInfo(tabId);
        return;
      }
      var tab = document.querySelector('.tab[data-tab="' + tabId + '"]');
      if (tab) tab.click();
    });
  });
}

function showFeatureInfo(tabId) {
  var info = {
    "tab-material": {title: "材料分析 Material", desc: "碳当量(CE/IW) | 可焊性评估(CSI) | 焊材兼容性推荐 | 微观组织预测 | HAZ硬度估算", descEn: "Carbon Equivalent | Weldability CSI | Filler Compatibility | Microstructure | HAZ Hardness"},
    "tab-thermal": {title: "热学分析 Thermal", desc: "Rosenthal 2D/3D温度场 | 热输入(kJ/mm) | t8/5冷却时间 | HAZ宽度 | 峰值温度分布", descEn: "Rosenthal 2D/3D | Heat Input | t8/5 Cooling | HAZ Width | Peak Temps"},
    "tab-mechanical": {title: "力学分析 Mechanical", desc: "残余应力(纵向/横向) | 强度预测 | 变形分析 | 硬度分布 | 疲劳S-N估算", descEn: "Residual Stress | Strength Prediction | Deformation | Hardness | Fatigue S-N"},
    "tab-fluid": {title: "流体分析 Fluid", desc: "Marangoni数 | 熔池几何(W/D) | 浮力效应(Ra) | 粘度温度系数 | 表面张力梯度", descEn: "Marangoni | Pool Geometry | Buoyancy | Viscosity | Surface Tension"},
    "tab-em": {title: "电磁分析 EM", desc: "洛伦兹力 | 磁偏吹评估 | 电磁搅拌(Hartmann) | 电流密度分布 | 电弧压力", descEn: "Lorentz Force | Arc Blow | EM Stirring | Current Density | Arc Pressure"},
    "tab-env": {title: "环境分析 Environment", desc: "12种服役环境 | 腐蚀速率 | HIC风险评估 | 服役寿命 | 疲劳寿命 | 环境断裂", descEn: "12 Environments | Corrosion Rate | HIC Risk | Service Life | Fatigue | EAC"}
  };
  var d = info[tabId] || info["tab-material"];
  var h = '<div class="feature-info-card">';
  h += '<h3 style="color:var(--accent)">' + d.title + '</h3>';
  h += '<p style="color:var(--text);margin:10px 0">' + d.desc + '</p>';
  h += '<p style="color:var(--text2);font-size:12px">' + d.descEn + '</p>';
  h += '<p style="margin-top:16px;color:var(--accent);font-size:12px">Run full analysis for detailed results</p>';
  h += '</div>';
  showResults();
  document.getElementById("tab-summary").innerHTML = h;
  setActiveTab("tab-summary");
}


function showFeatureInfo(tabId) {
  showResults(); // show results container
  var info = {
    "tab-material": {title: "材料分析 Material Analysis", cn: "材料", en: "Material", 
      desc: "碳当量(CE/IW)计算、可焊性评估(Crack Susceptibility Index)、焊材兼容性推荐、微观组织预测、HAZ硬度估算",
      desc_en: "Carbon Equivalent (CE/IW), Weldability Assessment (CSI), Filler Compatibility, Microstructure prediction, HAZ hardness estimation"},
    "tab-thermal": {title: "热学分析 Thermal Analysis", cn: "热学", en: "Thermal",
      desc: "Rosenthal 2D/3D温度场模型、热输入计算(Heat Input kJ/mm)、t8/5冷却时间、HAZ宽度预测、峰值温度分布",
      desc_en: "Rosenthal 2D/3D thermal models, Heat Input (kJ/mm), t8/5 cooling time, HAZ width prediction, Peak temperature distribution"},
    "tab-mechanical": {title: "力学分析 Mechanical Analysis", cn: "力学", en: "Stress",
      desc: "残余应力估算(纵向/横向)、焊接强度预测(屈服/抗拉)、变形分析(角变形/收缩)、硬度分布、疲劳S-N估算",
      desc_en: "Residual stress estimation (longitudinal/transverse), Strength prediction (yield/tensile), Deformation analysis, Hardness profile, Fatigue S-N estimation"},
    "tab-fluid": {title: "流体分析 Fluid Dynamics", cn: "流体", en: "Fluid",
      desc: "Marangoni数(表面张力驱动流)、熔池几何(宽度/深度/长宽比)、浮力效应(Rayleigh数)、粘度与表面张力温度系数",
      desc_en: "Marangoni number (surface tension driven flow), Weld pool geometry (W/D ratio), Buoyancy effects (Rayleigh number), Viscosity & surface tension temperature coefficients"},
    "tab-em": {title: "电磁分析 Electromagnetic", cn: "电磁", en: "EM",
      desc: "洛伦兹力计算、磁偏吹评估(Arc Blow)、电磁搅拌效应(Hartmann数)、电流密度分布、电弧压力估算",
      desc_en: "Lorentz force calculation, Arc blow assessment, EM stirring (Hartmann number), Current density distribution, Arc pressure estimation"},
    "tab-env": {title: "环境分析 Environmental", cn: "环境", en: "Env",
      desc: "服役环境匹配(12种)、腐蚀速率预测、氢致裂纹(HIC)风险评估、服役寿命估算、疲劳寿命预测、环境敏感断裂评估",
      desc_en: "Service environment matching (12 types), Corrosion rate prediction, HIC risk assessment, Service life estimation, Fatigue life prediction, Environment-assisted cracking assessment"}
  };
  var d = info[tabId] || info["tab-material"];
  var h = '<div class="feature-info-card">';
  h += '<h3>' + d.title + '</h3>';
  h += '<p style="color:var(--text2);margin-bottom:12px">' + d.desc + '</p>';
  h += '<p style="color:var(--text3);font-size:12px">' + d.desc_en + '</p>';
  h += '<p style="margin-top:16px;color:var(--accent)">请运行完整分析以获取详细数据<br>Run full analysis for detailed data</p>';
  h += '</div>';
  document.getElementById("tab-summary").innerHTML = h;
  setActiveTab("tab-summary");
}

function setupProcessDefaults() {
  var defaults = {
    GTAW: {efficiency:0.70, electrode:2.4},
    GMAW: {efficiency:0.80, electrode:1.2},
    SMAW: {efficiency:0.75, electrode:3.2},
    FCAW: {efficiency:0.80, electrode:1.6},
    SAW: {efficiency:0.95, electrode:4.0},
    PAW: {efficiency:0.75, electrode:3.0},
    LBW: {efficiency:0.85, electrode:0.3},
    EBW: {efficiency:0.90, electrode:0.5}
  };
  document.getElementById("sel-process").addEventListener("change", function(e) {
    var d = defaults[e.target.value];
    if (d) {
      document.getElementById("inp-efficiency").value = d.efficiency;
      document.getElementById("inp-electrode").value = d.electrode;
    }
  });
}

async function loadMaterials() {
  try {
    var res = await fetch(API + "/materials");
    var data = await res.json();
    populateMaterials(data.materials);
    showStatus("Materials loaded from server (" + Object.keys(data.materials).length + ")", "success");
  } catch (e) {
    populateMaterials(FALLBACK_MATERIALS);
    showStatus("Materials loaded (" + Object.keys(FALLBACK_MATERIALS).length + ")", "success");
  }
}

async function loadEnvironments() {
  try {
    var res = await fetch(API + "/environments");
    var data = await res.json();
    populateEnvironments(data.environments);
    showStatus("Environments loaded", "success");
  } catch (e) {
    populateEnvironments(FALLBACK_ENVIRONMENTS);
    showStatus("Environments loaded (" + FALLBACK_ENVIRONMENTS.length + ")", "success");
  }
}


function gatherInput() {
  var fmk = document.getElementById("sel-filler-mat").value;
  return {
    id: "weld-" + Date.now(),
    base_material_key: document.getElementById("sel-base-mat").value || "Q345",
    filler_material_key: fmk || null,
    parameters: {
      process: document.getElementById("sel-process").value,
      current: parseFloat(document.getElementById("inp-current").value) || 150,
      voltage: parseFloat(document.getElementById("inp-voltage").value) || 20,
      travel_speed: parseFloat(document.getElementById("inp-speed").value) || 2,
      arc_efficiency: parseFloat(document.getElementById("inp-efficiency").value) || 0.75,
      electrode_diameter: parseFloat(document.getElementById("inp-electrode").value) || 2.4,
      torch_angle: parseFloat(document.getElementById("inp-torch-angle").value) || 90,
      travel_angle: parseFloat(document.getElementById("inp-travel-angle").value) || 0,
      arc_length: parseFloat(document.getElementById("inp-arc-length").value) || 3,
      polarity: document.getElementById("sel-polarity").value,
      preheat_temp: parseFloat(document.getElementById("inp-preheat").value) || 25,
      interpass_temp: parseFloat(document.getElementById("inp-interpass").value) || 150
    },
    joint: {
      joint_type: document.getElementById("sel-joint-type").value,
      position: document.getElementById("sel-position").value,
      plate_thickness: parseFloat(document.getElementById("inp-thickness").value) || 10,
      bevel_angle: parseFloat(document.getElementById("inp-bevel").value) || 30,
      groove_type: document.getElementById("sel-groove").value,
      number_of_passes: parseInt(document.getElementById("inp-passes").value) || 3
    },
    environment: document.getElementById("sel-environment").value || "indoor_standard"
  };
}

function showResults() {
  document.getElementById("empty-state").classList.add("hidden");
  document.getElementById("results-container").classList.remove("hidden");
}

function showStatus(msg, type) {
  var el = document.getElementById("status");
  el.textContent = msg;
  el.className = "status show " + (type || "loading");
  if (type === "success") setTimeout(function() { el.classList.remove("show"); }, 3000);
}

function renderQualityBar(q) {
  var grade = q.grade || "?";
  var score = q.quality_score || 0;
  var bar = document.getElementById("quality-bar");
  bar.className = "quality-bar grade-" + grade;
  bar.innerHTML = '<span class="quality-grade">' + grade + '</span><div><div style="font-size:14px">质量分数 Quality Score: ' + score + ' / 100</div><div style="font-size:11px;color:var(--text2);margin-top:2px">风险评估 Risk: ' + (q.risk_assessment || "N/A") + '</div></div>';
}

function setActiveTab(tabId) {
  document.querySelectorAll(".tab").forEach(function(t) { t.classList.remove("active"); });
  document.querySelectorAll(".tab-panel").forEach(function(p) { p.classList.remove("active"); });
  var tab = document.querySelector('.tab[data-tab="' + tabId + '"]');
  if (tab) tab.classList.add("active");
  var panel = document.getElementById(tabId);
  if (panel) {
    panel.classList.add("active");
    if (tabId === "tab-thermal" && currentResults) setTimeout(function() { drawPeakTempChart(currentResults.thermal); }, 150);
  }
}

async function runAnalysis() {
  showStatus("Running full analysis...", "loading");
  var input = gatherInput();
  try {
    var res = await fetch(API + "/analyze", {
      method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify(input)
    });
    var data = await res.json();
    currentResults = data;
    showResults();
    renderQualityBar(data.quality || {});
    renderAllTabs(data);
    setActiveTab("tab-summary");
    showStatus("Analysis complete", "success");
  } catch (e) {
    showStatus("Analysis failed: " + e.message, "error");
  }
}

async function runInference() {
  showStatus("Running cross-domain inference...", "loading");
  var input = gatherInput();
  try {
    var res = await fetch(API + "/inference", {
      method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify(input)
    });
    var data = await res.json();
    currentInference = data;
    if (!currentResults) showResults();
    renderInferenceTab(data);
    setActiveTab("tab-inference");
    showStatus("Inference complete", "success");
  } catch (e) {
    showStatus("Inference failed: " + e.message, "error");
  }
}

async function runQuickCheck() {
  showStatus("Running quick check...", "loading");
  var input = gatherInput();
  try {
    var res = await fetch(API + "/quick", {
      method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify(input)
    });
    var data = await res.json();
    showStatus("Quick check: Score " + data.quality_score + " / Grade " + data.grade, "success");
  } catch (e) {
    showStatus("Quick check failed: " + e.message, "error");
  }
}

async function generateReport() {
  showStatus("Generating report...", "loading");
  var input = gatherInput();
  var params = new URLSearchParams({
    base_material_key: input.base_material_key,
    filler_material_key: input.filler_material_key || "",
    process: input.parameters.process,
    current: input.parameters.current,
    voltage: input.parameters.voltage,
    travel_speed: input.parameters.travel_speed,
    joint_type: input.joint.joint_type,
    plate_thickness: input.joint.plate_thickness,
    environment: input.environment
  });
  try {
    var res = await fetch(API + "/report?" + params.toString());
    var data = await res.json();
    document.getElementById("report-body").textContent = data.report;
    document.getElementById("report-modal").classList.remove("hidden");
    showStatus("Report ready", "success");
  } catch (e) {
    showStatus("Report failed: " + e.message, "error");
  }
}

async function runSensitivity() {
  showStatus("Running auto-sensitivity...", "loading");
  var input = gatherInput();
  try {
    var res = await fetch(API + "/auto-sensitivity", {
      method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify(input)
    });
    var data = await res.json();
    if (!currentResults) showResults();
    renderSensitivityTab(data);
    setActiveTab("tab-sensitivity");
    showStatus("Sensitivity analysis complete", "success");
  } catch (e) {
    showStatus("Sensitivity failed: " + e.message, "error");
  }
}

async function saveScenario() {
  var input = gatherInput();
  try {
    var res = await fetch(API + "/scenarios/save", {
      method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify(input)
    });
    var data = await res.json();
    showStatus("Saved: " + data.filename, "success");
  } catch (e) {
    showStatus("Save failed: " + e.message, "error");
  }
}

async function toggleScenarios() {
  showStatus("Loading saved scenarios...", "loading");
  try {
    var res = await fetch(API + "/scenarios");
    var data = await res.json();
    var list = data.scenarios || [];
    if (!list.length) { showStatus("No saved scenarios found", "error"); return; }
    alert("Saved scenarios:\n" + list.join("\n"));
    showStatus(list.length + " scenario(s) found", "success");
  } catch (e) {
    showStatus("Load failed: " + e.message, "error");
  }
}

async function toggleCompare() {
  var input = gatherInput();
  compareScenarios.push(input);
  if (compareScenarios.length < 2) {
    showStatus("Added scenario " + compareScenarios.length + ". Add one more to compare.", "loading");
    return;
  }
  showStatus("Running comparison (" + compareScenarios.length + " scenarios)...", "loading");
  try {
    var res = await fetch(API + "/compare", {
      method: "POST", headers: {"Content-Type": "application/json"},
      body: JSON.stringify({ scenarios: compareScenarios })
    });
    var data = await res.json();
    if (!currentResults) showResults();
    renderCompareTab(data);
    setActiveTab("tab-compare");
    compareScenarios = [];
    showStatus("Comparison complete", "success");
  } catch (e) {
    compareScenarios = [];
    showStatus("Compare failed: " + e.message, "error");
  }
}

function toggleBatch() {
  document.getElementById("batch-modal").classList.remove("hidden");
}

function closeBatch() {
  document.getElementById("batch-modal").classList.add("hidden");
}

async function runBatchCSV() {
  var csv = document.getElementById("batch-csv").value;
  if (!csv.trim()) { showStatus("请粘贴CSV数据 Paste CSV data first", "error"); return; }
  showStatus("Running batch...", "loading");
  try {
    var res = await fetch(API + "/batch-csv", {
      method: "POST", headers: {"Content-Type": "application/json"},
      body: JSON.stringify({ csv_data: csv })
    });
    var data = await res.json();
    showStatus("Batch complete: " + data.count + " scenarios", "success");
    closeBatch();
  } catch (e) {
    showStatus("Batch failed: " + e.message, "error");
  }
}

function card(label, value) {
  return '<div class="info-card"><div class="label">' + label + '</div><div class="value">' + value + '</div></div>';
}

function renderAllTabs(data) {
  var q = data.quality || {};
  var a = data.analysis || {};
  var summary = a.summary || {};

  // Summary tab
  var s = '<div class="info-grid">';
  s += card("材料 Material", summary.base_material || "N/A");
  s += card("工艺 Process", summary.weld_process || "N/A");
  s += card("质量分数 Score", q.quality_score + " / 100");
  s += card("质量等级 Grade", q.grade || "N/A");
  s += card("综合风险 Risk", summary.overall_risk || "N/A");
  s += card("焊接性 Weldability", summary.weldability || "N/A");
  s += '</div>';
  var recs = summary.recommendations || [];
  if (recs.length) {
    s += '<h4 style="margin:12px 0 8px;color:var(--text2)">建议 Recommendations</h4><ul class="recommendation-list">';
    recs.forEach(function(r) { s += '<li>' + r + '</li>'; });
    s += '</ul>';
  }
  document.getElementById("tab-summary").innerHTML = s;

  // Material tab
  renderDomainTab("tab-material", a.material || {}, "材料分析 Material Analysis");

  // Thermal tab
  var t = a.thermal || {};
  var th = '<div class="info-grid">';
  th += card("峰值温度 Peak Temp", (t.peak_temperature_C || "N/A") + " C");
  th += card("冷却速率 Cooling Rate", (t.cooling_rate_C_per_s || "N/A") + " C/s");
  th += card("热输入 Heat Input", (t.heat_input_kJ_mm || "N/A") + " kJ/mm");
  th += card("HAZ宽度 HAZ Width", (t.haz_width_mm || "N/A") + " mm");
  th += card("预热 Preheat", (t.recommended_preheat_C || t.preheat_temp || "N/A") + " C");
  th += card("层间 Interpass", (t.interpass_temp || "N/A") + " C");
  th += '</div>';
  if (t.peak_temperatures && t.peak_temperatures.length) {
    th += '<div class="chart-container" style="margin-top:10px;height:280px"><canvas id="chart-peak-temp"></canvas></div>';
  }
  document.getElementById("tab-thermal").innerHTML = th;
  if (t.peak_temperatures) setTimeout(function() { drawPeakTempChart(t); }, 200);

  // Mechanical tab
  renderDomainTab("tab-mechanical", a.mechanical || {}, "力学分析 Mechanical Analysis");

  // Fluid tab
  renderDomainTab("tab-fluid", a.fluid || a.fluid_dynamics || {}, "流体分析 Fluid Dynamics");

  // EM tab
  renderDomainTab("tab-em", a.electromagnetic || a.em || {}, "电磁分析 EM Analysis");

  // Environmental tab
  var env = a.environmental || {};
  var eh = '<div class="info-grid">';
  var envKeys = ["corrosion_rate_mm_per_year", "estimated_service_life_years", "corrosion_risk", "fatigue_limit_MPa", "fatigue_life_years", "hicc_risk", "risk_score", "environment"];
  envKeys.forEach(function(k) {
    if (env[k] !== undefined) {
      var label = k.replace(/_/g, " ").replace(/\b\w/g, function(c) { return c.toUpperCase(); });
      var val = typeof env[k] === "number" ? (Number.isInteger(env[k]) ? env[k] : env[k].toFixed(2)) : String(env[k]);
      eh += card(label, val);
    }
  });
  eh += '</div>';
  var envRecs = env.recommendations || env.mitigations || [];
  if (envRecs.length) {
    eh += '<h4 style="margin:12px 0 8px;color:var(--text2)">环境建议 Environmental Recommendations</h4><ul class="recommendation-list">';
    envRecs.forEach(function(r) { eh += '<li>' + r + '</li>'; });
    eh += '</ul>';
  }
  document.getElementById("tab-env").innerHTML = eh;

  // Energy tab
  var en = a.energy || {};
  var enh = '<div class="info-grid">';
  var pd = en.power_density || {};
  enh += card("电弧功率 Arc Power", (pd.arc_power_W || "N/A") + " W");
  enh += card("功率密度 Power Density", (pd.power_density_W_per_mm2 || "N/A") + " W/mm2");
  var ee = en.energy_efficiency || {};
  enh += card("熔化效率 Melt Eff", (ee.melt_efficiency_pct || "N/A") + " %");
  enh += card("有用能量 Useful Energy", (ee.useful_energy_W || "N/A") + " W");
  enh += card("辐射损失 Radiation Loss", (ee.loss_radiation_W || "N/A") + " W");
  enh += card("对流损失 Convection Loss", (ee.loss_convection_W || "N/A") + " W");
  enh += '</div>';
  var eb = en.energy_balance || {};
  enh += '<h4 style="margin:10px 0 6px;color:var(--text2)">能量平衡 Energy Balance</h4><div class="info-grid">';
  enh += card("熔化能量 Melting", (eb.energy_melting_pct || "N/A") + " %");
  enh += card("HAZ能量 HAZ", (eb.energy_haz_pct || "N/A") + " %");
  enh += card("母材能量 Base", (eb.energy_base_pct || "N/A") + " %");
  enh += card("损失 Loss", (eb.energy_loss_pct || "N/A") + " %");
  enh += '</div>';
  document.getElementById("tab-energy").innerHTML = enh;

}

function renderDomainTab(id, domain, title) {
  var h = '<div class="info-grid">';
  Object.entries(domain).forEach(function(entry) {
    var k = entry[0], v = entry[1];
    if (typeof v === "object" || k === "peak_temperatures" || k === "detailed_sweeps") return;
    var label = k.replace(/_/g, " ").replace(/\b\w/g, function(c) { return c.toUpperCase(); });
    var val = typeof v === "number" ? (Number.isInteger(v) ? v : v.toFixed(2)) : String(v);
    h += card(label, val);
  });
  h += '</div>';
  document.getElementById(id).innerHTML = h;
}

function renderInferenceTab(data) {
  var inferences = data.inferences || data.cross_domain_inferences || [];
  var h = '<h3 style="margin-bottom:8px">跨领域推理 Cross-Domain Inference</h3>';
  if (!inferences.length) {
    h += '<p style="color:var(--text2)">暂无推理结果 No inference results available.</p>';
  } else {
    inferences.forEach(function(inf) {
      h += '<div class="inference-card">';
      h += '<div class="i-domain">' + (inf.domain || inf.type || "Inference") + '</div>';
      h += '<div class="i-finding">' + (inf.finding || inf.description || "") + '</div>';
      h += '<div class="i-rec">' + (inf.implication || inf.recommendation || "") + '</div>';
      h += '</div>';
    });
  }
  document.getElementById("tab-inference").innerHTML = h;
}

function renderSensitivityTab(data) {
  var rankings = data.sensitivity_ranking || data.rankings || [];
  var h = '<h3 style="margin-bottom:8px">参数敏感性分析 Sensitivity Analysis</h3>';
  if (rankings.length) {
    h += '<div class="info-grid">';
    rankings.forEach(function(r) {
      h += '<div class="info-card"><div class="label">' + r.parameter + '</div>';
      h += '<div class="value">' + (r.impact_score || r.score || 0).toFixed(1) + ' pts</div>';
      h += '<div class="sub">' + (r.interpretation || "") + '</div></div>';
    });
    h += '</div>';
  }
  if (data.detailed_sweeps || data.sweeps) {
    h += '<div class="chart-container" style="margin-top:10px;height:300px"><canvas id="chart-sensitivity"></canvas></div>';
  }
  document.getElementById("tab-sensitivity").innerHTML = h;
  if (data.detailed_sweeps || data.sweeps) setTimeout(function() { drawSensitivityChart(data); }, 200);
}

function renderCompareTab(data) {
  var sc = data.scenarios || [];
  var h = '<h3 style="margin-bottom:10px">情景对比 Comparison (' + sc.length + ' scenarios)</h3>';
  h += '<div style="overflow-x:auto"><table class="comp-table"><thead><tr>';
  h += '<th>#</th><th>材料 Material</th><th>工艺 Process</th><th>环境 Env</th><th>分数 Score</th><th>等级 Grade</th><th>HAZ</th><th>应力 Stress</th><th>腐蚀 Corr</th><th>寿命 Life</th><th>风险 Risk</th>';
  h += '</tr></thead><tbody>';
  var bi = data.comparison ? (data.comparison.best_scenario || {}).index : -1;
  var wi = data.comparison ? (data.comparison.worst_scenario || {}).index : -1;
  sc.forEach(function(s, i) {
    var cls = i === bi ? "best" : (i === wi ? "worst" : "");
    h += '<tr class="' + cls + '"><td>' + (i + 1) + '</td>';
    h += '<td>' + (s.material || "") + '</td><td>' + (s.process || "") + '</td><td>' + (s.environment || "") + '</td>';
    h += '<td><strong>' + (s.quality_score || 0) + '</strong></td><td>' + (s.quality_grade || "") + '</td>';
    h += '<td>' + (s.haz_width_mm || "") + '</td><td>' + Math.round(s.residual_stress_MPa || 0) + '</td>';
    h += '<td>' + (s.corrosion_rate_mm_per_yr || "") + '</td><td>' + Math.round(s.service_life_years || 0) + '</td>';
    h += '<td><span class="risk-badge risk-' + ((s.overall_risk || "low").toLowerCase().replace(/ /g, "-")) + '">' + (s.overall_risk || "") + '</span></td></tr>';
  });
  h += '</tbody></table></div>';
  if (data.comparison && data.comparison.trade_off_analysis && data.comparison.trade_off_analysis.length) {
    h += '<h4 style="margin-top:12px">权衡分析 Trade-off</h4>';
    data.comparison.trade_off_analysis.forEach(function(t) {
      h += '<div class="inference-card"><div class="i-domain">' + (t.type || "") + '</div>';
      h += '<div class="i-finding">' + (t.finding || t.finding_cn || "") + '</div>';
      h += '<div class="i-rec">' + (t.implication || t.implication_cn || "") + '</div></div>';
    });
  }
  document.getElementById("tab-compare").innerHTML = h;
}

// Charts
function drawPeakTempChart(t) {
  var canvas = document.getElementById("chart-peak-temp");
  if (!canvas) return;
  if (peakTempChart) peakTempChart.destroy();
  var pts = (t && t.peak_temperatures) ? t.peak_temperatures : [];
  if (!pts.length) return;
  peakTempChart = new Chart(canvas.getContext("2d"), {
    type: "line",
    data: {
      labels: pts.map(function(p) { return (p.distance_from_center_mm || 0) + " mm"; }),
      datasets: [{
        label: "峰值温度 Peak Temp (C)",
        data: pts.map(function(p) { return p.peak_temperature_C || 0; }),
        borderColor: "#e74c3c",
        backgroundColor: "rgba(231,76,60,0.1)",
        fill: true, tension: 0.3, pointRadius: 4
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { labels: { color: "#9298a8", font: { size: 10 } } } },
      scales: {
        x: { ticks: { color: "#9298a8" }, grid: { color: "rgba(45,49,64,0.5)" } },
        y: { title: { display: true, text: "温度 Temp (C)", color: "#9298a8" }, ticks: { color: "#9298a8" }, grid: { color: "rgba(45,49,64,0.5)" } }
      }
    }
  });
}

function drawSensitivityChart(data) {
  var canvas = document.getElementById("chart-sensitivity");
  if (!canvas) return;
  if (sensitivityChart) sensitivityChart.destroy();
  var sweeps = data.detailed_sweeps || data.sweeps || {};
  var datasets = [];
  var colors = ["#4a9eff", "#e74c3c", "#2ecc71", "#f1c40f", "#e67e22", "#6c5ce7"];
  var idx = 0;
  Object.entries(sweeps).forEach(function(entry) {
    var param = entry[0], sweep = entry[1];
    if (!sweep.results || !sweep.results.length) return;
    datasets.push({
      label: param,
      data: sweep.results.map(function(r) { return { x: r.parameter_value || 0, y: r.quality_score || 0 }; }),
      borderColor: colors[idx % colors.length],
      tension: 0.3, pointRadius: 3, fill: false
    });
    idx++;
  });
  if (!datasets.length) return;
  sensitivityChart = new Chart(canvas.getContext("2d"), {
    type: "line",
    data: { datasets: datasets },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { labels: { color: "#9298a8", font: { size: 9 } } } },
      scales: {
        x: { type: "linear", title: { display: true, text: "参数值 Parameter Value", color: "#9298a8" }, ticks: { color: "#9298a8", font: { size: 9 } }, grid: { color: "rgba(45,49,64,0.5)" } },
        y: { title: { display: true, text: "质量分数 Quality Score", color: "#9298a8" }, ticks: { color: "#9298a8", font: { size: 9 } }, grid: { color: "rgba(45,49,64,0.5)" } }
      }
    }
  });
}

// Modal & Tabs
function closeReport() { document.getElementById("report-modal").classList.add("hidden"); }

function copyReport() {
  navigator.clipboard.writeText(document.getElementById("report-body").textContent)
    .then(function() { showStatus(currentLang === "zh" ? "已复制" : "Copied", "success"); });
}

function setupTabs() {
  document.getElementById("tab-nav").addEventListener("click", function(e) {
    if (!e.target.classList.contains("tab")) return;
    setActiveTab(e.target.dataset.tab);
  });
}


// ===== Experiment Management =====
async function saveToExperiments() {
  var input = gatherInput();
  input.name = prompt("Experiment name:", "Weld-" + new Date().toISOString().slice(0,10));
  if (!input.name) return;
  showStatus("Saving experiment...", "loading");
  try {
    var res = await fetch(API + "/experiments", {
      method: "POST", headers: {"Content-Type":"application/json"}, body: JSON.stringify({
        name: input.name,
        base_material_key: input.base_material_key,
        filler_material_key: input.filler_material_key,
        parameters: input.parameters,
        joint: input.joint,
        environment: input.environment,
        notes: ""
      })
    });
    var data = await res.json();
    showStatus("Experiment saved: #" + data.id, "success");
  } catch (e) {
    showStatus("Failed: " + e.message, "error");
  }
}
async function loadExperiments() {
  showStatus("Loading experiments...", "loading");
  try {
    var res = await fetch(API + "/experiments?limit=20");
    var data = await res.json();
    if (!currentResults) showResults();
    renderStatsTab(data);
    setActiveTab("tab-stats");
    showStatus(data.total + " experiments loaded", "success");
  } catch (e) {
    showStatus("Failed: " + e.message, "error");
  }
}
function renderStatsTab(data) {
  var exps = data.experiments || [];
  var h = '<h3 style="margin-bottom:8px">实验结果 Experiments (' + (data.total || 0) + ')</h3>';
  if (!exps.length) {
    h += '<p style="color:var(--text2)">No experiments yet. Run analysis then click Save.</p>';
    document.getElementById("tab-stats").innerHTML = h;
    return;
  }
  h += '<div style="overflow-x:auto"><table class="comp-table"><thead><tr>';
  h += '<th>ID</th><th>Name</th><th>Material</th><th>Process</th><th>Env</th><th>Score</th><th>Grade</th><th>Risk</th><th>Date</th>';
  h += '</tr></thead><tbody>';
  exps.forEach(function(e) {
    var riskCls = "risk-" + ((e.overall_risk || "low").toLowerCase().replace(/ /g, "-"));
    h += '<tr><td>' + e.id + '</td><td>' + (e.name || "") + '</td><td>' + (e.material || "") + '</td>';
    h += '<td>' + (e.process || "") + '</td><td>' + (e.environment || "") + '</td>';
    h += '<td><strong>' + (e.quality_score || 0) + '</strong></td><td>' + (e.quality_grade || "") + '</td>';
    h += '<td><span class="risk-badge ' + riskCls + '">' + (e.overall_risk || "") + '</span></td>';
    h += '<td>' + (e.created_at || "").slice(0,10) + '</td></tr>';
  });
  h += '</tbody></table></div>';
  document.getElementById("tab-stats").innerHTML = h;
}
