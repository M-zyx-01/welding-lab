﻿"""
Welding Intelligence Lab - Server Launcher
焊接智能分析实验室 - 服务器启动器
Double-click start_server.bat or run: python run_server.py
"""
import sys, os, webbrowser

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, PROJECT_ROOT)
os.chdir(PROJECT_ROOT)

HOST = "127.0.0.1"
PORT = 8716

def check_deps():
    missing = []
    for pkg in ("fastapi", "uvicorn", "pydantic"):
        try:
            __import__(pkg)
        except ImportError:
            missing.append(pkg)
    if missing:
        print(f"  Installing: {', '.join(missing)}...")
        import subprocess
        subprocess.check_call([sys.executable, "-m", "pip", "install"] + missing, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

def main():
    print("=" * 55)
    print("  Welding Intelligence Lab")
    print("=" * 55)
    print("[1/2] Loading...")
    check_deps()
    from backend.main import app
    print(f"      {len(app.routes)} API routes loaded")
    url = f"http://{HOST}:{PORT}"
    print(f"[2/2] Server: {url}")
    print("      Ctrl+C to stop")
    print("=" * 55)
    webbrowser.open(url)
    import uvicorn
    uvicorn.run(app, host=HOST, port=PORT, log_level="info")

if __name__ == "__main__":
    main()
