﻿@echo off
chcp 65001 >nul
title Welding Intelligence Lab

echo ========================================
echo   Welding Intelligence Lab
echo ========================================
echo.

cd /d "E:\焊接\welding-lab-github"

REM Try python3, then python
python run_server.py 2>nul
if %errorlevel% neq 0 (
    python3 run_server.py 2>nul
)
if %errorlevel% neq 0 (
    echo.
    echo [ERROR] Python not found or failed to start.
    echo Install Python 3.9+ from https://python.org
    echo Then run: pip install fastapi uvicorn pydantic
)
pause
