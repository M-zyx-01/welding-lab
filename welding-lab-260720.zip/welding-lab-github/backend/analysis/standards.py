"""
Standards compliance engine: GB 50661, AWS D1.1 checks, WPS draft generation.
标准合规引擎：GB 50661、AWS D1.1检查、WPS草稿生成。
"""
from datetime import datetime
from typing import List, Optional
from ..data.weld_data import WeldInput, WeldParameters, WeldJoint, MaterialSpec, Environment, WeldProcess
from ..models.material import carbon_equivalent


def check_gb50661(weld: WeldInput) -> dict:
    """Check weld parameters against GB 50661-2011 (Steel Structure Welding Code).
    对照GB 50661-2011《钢结构焊接规范》检查焊接参数。"""
    checks = []
    params = weld.parameters
    mat = weld.base_material
    joint = weld.joint
    ce = carbon_equivalent(mat)
    if isinstance(ce, dict):
        ce = ce.get("ce_value", 0.4)
    plate_t = joint.plate_thickness

    # 1. Preheat check (Table 5.2.1 or similar)
    checks.append(_check_preheat_gb(mat, ce, plate_t, params.preheat_temp))

    # 2. Interpass temperature
    if params.interpass_temp > 300 and ce > 0.45:
        checks.append({"item": "Interpass / 层间温度", "pass": False,
                       "detail": f"Interpass {params.interpass_temp}C too high for CE={ce:.3f}. Max 250C recommended. / 层间温度{params.interpass_temp}C偏高，建议≤250C。",
                       "standard": "GB 50661 §5.3"})
    else:
        checks.append({"item": "Interpass / 层间温度", "pass": True,
                       "detail": f"Interpass {params.interpass_temp}C within range. / 层间温度{params.interpass_temp}C在范围内。",
                       "standard": "GB 50661 §5.3"})

    # 3. Heat input check for high-strength steels
    hi_kj = (params.arc_efficiency * params.voltage * params.current) / (params.travel_speed * 1000.0)
    if mat.yield_strength > 460e6 and hi_kj > 2.5:
        checks.append({"item": "Heat input / 热输入", "pass": False,
                       "detail": f"HSLA steel (YS={mat.yield_strength/1e6:.0f}MPa): heat input {hi_kj:.2f}kJ/mm exceeds 2.5kJ/mm limit. / 高强钢热输入{hi_kj:.2f}kJ/mm超过2.5kJ/mm限制。",
                       "standard": "GB 50661 §6.2"})
    else:
        checks.append({"item": "Heat input / 热输入", "pass": True,
                       "detail": f"Heat input {hi_kj:.2f}kJ/mm acceptable. / 热输入{hi_kj:.2f}kJ/mm可接受。",
                       "standard": "GB 50661 §6.2"})

    # 4. Joint geometry
    if joint.groove_type == "V" and joint.bevel_angle < 25:
        checks.append({"item": "Bevel angle / 坡口角度", "pass": False,
                       "detail": f"V-groove bevel {joint.bevel_angle}deg < 25 deg minimum. / V型坡口角度{joint.bevel_angle}°低于最小25°。",
                       "standard": "GB 50661 §4.2"})
    else:
        checks.append({"item": "Groove geometry / 坡口", "pass": True,
                       "detail": f"Groove geometry acceptable. / 坡口几何可接受。",
                       "standard": "GB 50661 §4.2"})

    # 5. Filler material matching
    if weld.filler_material:
        fy_ratio = weld.filler_material.yield_strength / mat.yield_strength if mat.yield_strength > 0 else 1
        if fy_ratio < 0.85:
            checks.append({"item": "Filler strength / 焊材强度", "pass": False,
                           "detail": f"Filler YS is {fy_ratio*100:.0f}% of base. Minimum 85% required. / 焊材屈服强度仅为母材的{fy_ratio*100:.0f}%，要求≥85%。",
                           "standard": "GB 50661 §7.1"})
        else:
            checks.append({"item": "Filler strength / 焊材强度", "pass": True,
                           "detail": f"Filler strength match: {fy_ratio*100:.0f}%. / 焊材强度匹配{fy_ratio*100:.0f}%。",
                           "standard": "GB 50661 §7.1"})

    return {
        "standard": "GB 50661-2011 / 钢结构焊接规范",
        "checks": checks,
        "passed": sum(1 for c in checks if c["pass"]),
        "failed": sum(1 for c in checks if not c["pass"]),
        "total": len(checks),
    }


def _check_preheat_gb(mat: MaterialSpec, ce: float, thickness: float,
                       actual_preheat: float) -> dict:
    """GB 50661 preheat temperature check.
    GB 50661预热温度检查。"""
    # Simplified from GB 50661 preheat tables
    if thickness <= 25:
        if ce < 0.35:
            req = 20
        elif ce < 0.45:
            req = 100
        elif ce < 0.60:
            req = 150
        else:
            req = 200
    elif thickness <= 50:
        if ce < 0.35:
            req = 50
        elif ce < 0.45:
            req = 150
        elif ce < 0.60:
            req = 200
        else:
            req = 300
    else:
        if ce < 0.35:
            req = 100
        elif ce < 0.45:
            req = 200
        elif ce < 0.60:
            req = 300
        else:
            req = 350
    passes = actual_preheat >= req
    return {
        "item": "Preheat / 预热温度",
        "pass": passes,
        "detail": (f"Required: {req}C, Actual: {actual_preheat}C. "
                   f"OK. / 要求{req}°C，实际{actual_preheat}°C，合格。" if passes else
                   f"Required: {req}C, Actual: {actual_preheat}C. "
                   f"Insufficient! / 要求{req}°C，实际{actual_preheat}°C，不足！"),
        "standard": "GB 50661 §5.2",
        "required_C": req,
        "actual_C": actual_preheat,
    }


def check_aws_d11(weld: WeldInput) -> dict:
    """Check weld parameters against AWS D1.1-2020 (Structural Welding Code - Steel).
    对照AWS D1.1-2020检查焊接参数。"""
    checks = []
    params = weld.parameters
    mat = weld.base_material
    joint = weld.joint
    ce = carbon_equivalent(mat)
    if isinstance(ce, dict):
        ce = ce.get("ce_value", 0.4)

    # 1. Preheat per AWS D1.1 Table 3.2
    checks.append(_check_preheat_aws(mat, ce, joint.plate_thickness, params.preheat_temp))

    # 2. Heat input limits per AWS D1.1 Table 3.7
    hi_kj = (params.arc_efficiency * params.voltage * params.current) / (params.travel_speed * 1000.0)
    if hi_kj > 5.5:
        checks.append({"item": "Heat input / 热输入", "pass": False,
                       "detail": f"Heat input {hi_kj:.2f}kJ/mm > 5.5kJ/mm AWS D1.1 limit. / 热输入超过AWS D1.1限制。",
                       "standard": "AWS D1.1 Table 3.7"})
    else:
        checks.append({"item": "Heat input / 热输入", "pass": True,
                       "detail": f"Heat input {hi_kj:.2f}kJ/mm within AWS D1.1 limits. / 热输入符合AWS D1.1。",
                       "standard": "AWS D1.1 Table 3.7"})

    # 3. Weld process qualification
    prequalified = params.process in (WeldProcess.SMAW, WeldProcess.GMAW,
                                       WeldProcess.FCAW, WeldProcess.SAW)
    checks.append({"item": "Process prequalified / 工艺预审", "pass": prequalified,
                   "detail": (f"{params.process.value} is AWS D1.1 prequalified. / 是AWS D1.1预审工艺。" if prequalified else
                              f"{params.process.value} requires qualification testing. / 需要工艺评定试验。"),
                   "standard": "AWS D1.1 §3"})

    # 4. Minimum fillet weld size
    if joint.joint_type.value in ("tee", "lap", "corner"):
        min_size = min(5.0, joint.plate_thickness * 0.75) if joint.plate_thickness <= 6 else max(5.0, joint.plate_thickness * 0.3)
        checks.append({"item": "Min fillet size / 最小角焊缝尺寸", "pass": True,
                       "detail": f"Recommended min: {min_size:.1f}mm based on {joint.plate_thickness}mm plate. / 建议最小角焊缝{min_size:.1f}mm。",
                       "standard": "AWS D1.1 Table 5.7"})

    return {
        "standard": "AWS D1.1-2020 / 钢结构焊接规范",
        "checks": checks,
        "passed": sum(1 for c in checks if c["pass"]),
        "failed": sum(1 for c in checks if not c["pass"]),
        "total": len(checks),
    }


def _check_preheat_aws(mat: MaterialSpec, ce: float, thickness: float,
                        actual_preheat: float) -> dict:
    """AWS D1.1 preheat check based on Table 3.2.
    AWS D1.1预热检查。"""
    # Simplified Table 3.2 logic
    if ce < 0.40:
        if thickness <= 20:
            req = 0  # none required
        elif thickness <= 40:
            req = 20
        elif thickness <= 65:
            req = 65
        else:
            req = 110
    elif ce < 0.55:
        if thickness <= 13:
            req = 20
        elif thickness <= 20:
            req = 65
        elif thickness <= 40:
            req = 110
        else:
            req = 150
    else:
        if thickness <= 13:
            req = 110
        elif thickness <= 20:
            req = 150
        else:
            req = 200
    passes = actual_preheat >= req
    return {
        "item": "Preheat (AWS) / 预热温度",
        "pass": passes,
        "detail": (f"Required: {req}C, Actual: {actual_preheat}C. OK. / OK" if passes else
                   f"Required: {req}C, Actual: {actual_preheat}C. INSUFFICIENT! / 不足！"),
        "standard": "AWS D1.1 Table 3.2",
        "required_C": req,
        "actual_C": actual_preheat,
    }


def generate_wps(weld: WeldInput) -> str:
    """Generate a WPS (Welding Procedure Specification) draft.
    生成WPS（焊接工艺规程）草稿。"""
    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    params = weld.parameters
    mat = weld.base_material
    joint = weld.joint
    filler = weld.filler_material
    lines = []
    lines.append("=" * 70)
    lines.append("  WELDING PROCEDURE SPECIFICATION (WPS) / 焊接工艺规程")
    lines.append("  (Draft generated by Welding Intelligence Lab — Verify before use)")
    lines.append("  (焊接智能分析实验室生成草稿 — 使用前请验证)")
    lines.append("=" * 70)
    lines.append(f"  WPS No.: WPS-{now[:10].replace('-','')}-{weld.id or '001'}")
    lines.append(f"  Date / 日期: {now}")
    lines.append(f"  Standard / 标准: GB 50661 / AWS D1.1")
    lines.append("")
    # Base Metal / 母材
    lines.append("-" * 70)
    lines.append("  1. BASE METAL / 母材")
    lines.append("-" * 70)
    lines.append(f"  Material / 材料: {mat.name} ({mat.grade})")
    lines.append(f"  Specification / 规格: {mat.composition}")
    lines.append(f"  Thickness Range / 厚度范围: {joint.plate_thickness} mm")
    lines.append("")
    # Filler Metal / 焊接材料
    lines.append("-" * 70)
    lines.append("  2. FILLER METAL / 焊接材料")
    lines.append("-" * 70)
    if filler:
        lines.append(f"  Filler / 焊材: {filler.name} ({filler.grade})")
    else:
        lines.append(f"  Filler / 焊材: Autogenous (self-fusing) / 自熔")
    lines.append(f"  Electrode Diameter / 焊条直径: {params.electrode_diameter or 'N/A'} mm")
    lines.append("")
    # Joint Design / 接头设计
    lines.append("-" * 70)
    lines.append("  3. JOINT DESIGN / 接头设计")
    lines.append("-" * 70)
    lines.append(f"  Joint Type / 接头类型: {joint.joint_type.value}")
    lines.append(f"  Groove Type / 坡口形式: {joint.groove_type}")
    lines.append(f"  Bevel Angle / 坡口角度: {joint.bevel_angle} deg")
    lines.append(f"  Root Gap / 根部间隙: {joint.root_gap} mm")
    lines.append(f"  Weld Position / 焊接位置: {joint.position.value}")
    lines.append(f"  Number of Passes / 焊道数: {joint.number_of_passes}")
    lines.append("")
    # Welding Parameters / 焊接参数
    lines.append("-" * 70)
    lines.append("  4. WELDING PARAMETERS / 焊接参数")
    lines.append("-" * 70)
    lines.append(f"  Process / 焊接方法: {params.process.value}")
    lines.append(f"  Current / 电流: {params.current} A")
    lines.append(f"  Voltage / 电压: {params.voltage} V")
    lines.append(f"  Travel Speed / 焊接速度: {params.travel_speed} mm/s")
    lines.append(f"  Polarity / 极性: {params.polarity}")
    lines.append(f"  Arc Efficiency / 电弧效率: {params.arc_efficiency}")
    lines.append(f"  Torch Angle / 焊枪角度: {params.torch_angle} deg")
    lines.append(f"  Arc Length / 弧长: {params.arc_length} mm")
    lines.append(f"  Electrode Stickout / 干伸长度: {params.stickout} mm")
    lines.append("")
    # Thermal / 热参数
    hi = (params.arc_efficiency * params.voltage * params.current) / (params.travel_speed * 1000.0)
    lines.append("-" * 70)
    lines.append("  5. THERMAL / 热参数")
    lines.append("-" * 70)
    lines.append(f"  Preheat Temp / 预热温度: {params.preheat_temp} C")
    lines.append(f"  Interpass Temp / 层间温度: {params.interpass_temp} C (max)")
    lines.append(f"  Heat Input / 热输入: {hi:.3f} kJ/mm")
    lines.append("")
    # Environment / 环境
    lines.append("-" * 70)
    lines.append("  6. SERVICE ENVIRONMENT / 服役环境")
    lines.append("-" * 70)
    lines.append(f"  Environment / 环境: {weld.environment.value}")
    lines.append("")
    lines.append("-" * 70)
    lines.append("  Prepared by / 编制: Welding Intelligence Lab")
    lines.append(f"  Date / 日期: {now}")
    lines.append("  This is a draft WPS. Verify all parameters before production use.")
    lines.append("  此为WPS草稿。生产使用前请验证所有参数。")
    lines.append("=" * 70)
    return "\n".join(lines)


def full_standards_check(weld: WeldInput) -> dict:
    """Run all standards checks and generate WPS.
    运行所有标准检查并生成WPS。"""
    gb = check_gb50661(weld)
    aws = check_aws_d11(weld)
    wps = generate_wps(weld)
    return {
        "gb_50661": gb,
        "aws_d11": aws,
        "wps_draft": wps,
        "all_pass": gb["failed"] == 0 and aws["failed"] == 0,
    }
