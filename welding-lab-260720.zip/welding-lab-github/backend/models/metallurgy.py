"""
Metallurgy model: CCT prediction, phase fractions, hardness distribution, HAZ zones.
金相组织预测：CCT预测、组织比例、硬度分布、HAZ亚区模型。

Based on classical welding metallurgy:
- Andrews (1965) for Ms temperature
- Kirkaldy (1984) kinetics for CCT prediction
- Koistinen-Marburger for martensite fraction
- Grong (1994) "Metallurgical Modelling of Welding"
- Easterling "Introduction to the Physical Metallurgy of Welding"
"""
import math
from typing import Optional, List, Dict
from ..data.weld_data import MaterialSpec, WeldParameters, WeldJoint


# ============================================================
# 1. Critical Transformation Temperatures / 临界相变温度
# ============================================================

def martensite_start_temperature(mat: MaterialSpec) -> float:
    """Ms temperature (Andrews 1965, linear formula).
    Ms温度（Andrews 1965线性公式）。"""
    c = mat.composition
    ms = (539.0 - 423.0 * c.get("C", 0) - 30.4 * c.get("Mn", 0)
          - 17.7 * c.get("Ni", 0) - 12.1 * c.get("Cr", 0)
          - 7.5 * c.get("Mo", 0) - 7.5 * c.get("Si", 0))
    return round(ms, 1)


def bainite_start_temperature(mat: MaterialSpec) -> float:
    """Bs temperature (empirical, from Grong 1994).
    Bs温度（Grong 1994经验公式）。"""
    c = mat.composition
    bs = (830.0 - 270.0 * c.get("C", 0) - 90.0 * c.get("Mn", 0)
          - 37.0 * c.get("Ni", 0) - 70.0 * c.get("Cr", 0)
          - 83.0 * c.get("Mo", 0))
    return round(bs, 1)


def ac1_temperature(mat: MaterialSpec) -> float:
    """Ac1 temperature (approximate from composition).
    Ac1温度（成分近似）。"""
    c = mat.composition
    ac1 = 723.0 - 10.7 * c.get("Mn", 0) - 16.9 * c.get("Ni", 0)
    ac1 = ac1 + 29.1 * c.get("Si", 0) + 16.9 * c.get("Cr", 0)
    return round(ac1, 1)


def ac3_temperature(mat: MaterialSpec) -> float:
    """Ac3 temperature (approximate from composition).
    Ac3温度（成分近似）。"""
    c = mat.composition
    ac3 = (910.0 - 203.0 * math.sqrt(c.get("C", 0)) + 44.7 * c.get("Si", 0)
           - 15.2 * c.get("Ni", 0) + 31.5 * c.get("Mo", 0) + 104.0 * c.get("V", 0))
    return round(ac3, 1)


def critical_transformation_temperatures(mat: MaterialSpec) -> dict:
    """All critical temperatures for a material.
    材料的全部临界相变温度。"""
    ms = martensite_start_temperature(mat)
    bs = bainite_start_temperature(mat)
    ac1 = ac1_temperature(mat)
    ac3 = ac3_temperature(mat)
    return {
        "Ms_C": ms,
        "Bs_C": bs,
        "Ac1_C": ac1,
        "Ac3_C": ac3,
        "note_Ms": ("Ms < 200 C: high hardenability / 高淬透性" if ms < 200 else
                     "Ms 200-350 C: moderate / 中等" if ms < 350 else
                     "Ms > 350 C: low hardenability / 低淬透性"),
    }


# ============================================================
# 2. Critical Cooling Times / 临界冷却时间
# ============================================================

def critical_cooling_times(mat: MaterialSpec) -> dict:
    """Critical t8/5 times for martensite (100%), bainite (50%), ferrite start.
    马氏体(100%)、贝氏体(50%)、铁素体开始的临界t8/5时间。

    Uses CE_IIW-based exponential regression calibrated to typical CCT data
    for low-alloy structural steels. Reference points:
      CE=0.40 (Q345): t_m=5s,  t_b=25s,  t_f=110s
      CE=0.45:         t_m=10s, t_b=50s,  t_f=220s
      CE=0.60 (Q690): t_m=30s, t_b=140s, t_f=620s
    """
    from ..models.material import carbon_equivalent
    ce = carbon_equivalent(mat) if isinstance(carbon_equivalent(mat), (int, float)) else carbon_equivalent(mat).get("ce_value", 0.4)
    if not isinstance(ce, (int, float)):
        ce = 0.4
    ce = max(0.1, min(ce, 1.2))
    # For Cr > 8% (P91/P92 type): always martensitic, CE formula breaks down
    if mat.composition.get("Cr", 0) > 8:
        return {
            "t_martensite_100pct_s": 9999.0,
            "t_bainite_50pct_s": 9999.0,
            "t_ferrite_start_s": 9999.0,
            "carbon_equivalent": round(ce, 3),
            "note": "High-Cr martensitic steel (P91/P92 type). Always air-hardening. "
                    "CE formula not applicable; requires specific PWHT regime. "
                    "/ 高Cr马氏体钢(P91/P92)，空淬钢。CE公式不适用；需要专门的热处理制度。",
        }
    import math
    t_martensite = math.exp(-1.975 + 8.96 * ce)
    t_bainite = math.exp(-0.5 + 9.0 * ce)
    t_ferrite = math.exp(1.0 + 9.0 * ce)
    return {
        "t_martensite_100pct_s": round(t_martensite, 2),
        "t_bainite_50pct_s": round(t_bainite, 2),
        "t_ferrite_start_s": round(t_ferrite, 2),
        "carbon_equivalent": round(ce, 3),
        "note": (
            f"Full martensite for t8/5 < {t_martensite:.1f}s | "
            f"Bainite dominant around {t_bainite:.1f}s | "
            f"Ferrite+pearlite for t8/5 > {t_ferrite:.1f}s"
        ),
    }


# ============================================================
# 3. Phase Fraction Prediction / 组织比例预测
# ============================================================

def predict_phase_fractions(mat: MaterialSpec, t85: float,
                             peak_temp_C: Optional[float] = None) -> dict:
    """Predict microstructure phase fractions from t8/5 cooling time.
    从t8/5冷却时间预测微观组织比例。

    Args:
        mat: Material specification
        t85: t8/5 cooling time in seconds
        peak_temp_C: Peak temperature reached (for HAZ). If None, assumes fusion line.

    Returns phase fractions (0-1) for martensite, bainite, ferrite+pearlite.
    """
    crit = critical_cooling_times(mat)
    t_m = crit["t_martensite_100pct_s"]
    t_b = crit["t_bainite_50pct_s"]
    t_f = crit["t_ferrite_start_s"]

    # Phase fraction calculation
    if t85 <= t_m:
        f_m = 1.0
        f_b = 0.0
        f_fp = 0.0
    elif t85 <= t_b:
        # Martensite + Bainite transition zone
        # Linear interpolation in log space
        log_frac = (math.log10(t85) - math.log10(t_m)) / (math.log10(t_b) - math.log10(t_m))
        f_m = 1.0 - 0.5 * log_frac  # 100% → 50% martensite
        f_b = 0.5 * log_frac         # 0% → 50% bainite
        f_fp = 0.0
    elif t85 <= t_f:
        # Bainite + Ferrite transition
        log_frac = (math.log10(t85) - math.log10(t_b)) / (math.log10(t_f) - math.log10(t_b))
        f_m = max(0.0, 0.5 - 0.5 * log_frac)  # residual martensite fades
        f_b = 0.5 * (1.0 - log_frac)           # 50% → 0% bainite
        f_fp = 0.5 * log_frac                   # 0% → 50% ferrite-pearlite
    else:
        # Ferrite + Pearlite dominant
        f_m = 0.0
        # Slow cooling: ferrite fraction increases, pearlite from remaining austenite
        excess = min((t85 - t_f) / t_f, 1.0)
        f_b = max(0.0, 0.1 - 0.1 * excess)
        f_fp = 1.0 - f_b

    # Normalize
    total = f_m + f_b + f_fp
    if total < 0.001:
        f_m, f_b, f_fp = 0.0, 0.0, 1.0
    else:
        f_m /= total
        f_b /= total
        f_fp /= total

    # For stainless steels: predict delta-ferrite instead
    is_stainless = mat.composition.get("Cr", 0) > 10
    delta_ferrite = None
    if is_stainless:
        delta_ferrite = _delta_ferrite_wrc1992(mat)

    return {
        "martensite_fraction": round(f_m, 3),
        "bainite_fraction": round(f_b, 3),
        "ferrite_pearlite_fraction": round(f_fp, 3),
        "delta_ferrite_FN": delta_ferrite,
        "predicted_microstructure": _describe_microstructure(f_m, f_b, f_fp, delta_ferrite),
    }


def _delta_ferrite_wrc1992(mat: MaterialSpec) -> float:
    """WRC-1992 diagram: delta-ferrite number (FN) prediction for stainless steels.
    WRC-1992图：不锈钢δ-铁素体含量预测。"""
    c = mat.composition
    cr_eq = (c.get("Cr", 0) + c.get("Mo", 0) + 0.7 * c.get("Nb", 0))
    ni_eq = (c.get("Ni", 0) + 35 * c.get("C", 0) + 20 * c.get("N", 0)
             + 0.25 * c.get("Cu", 0))
    if cr_eq < 17 or ni_eq < 5:
        return None
    # FN from WRC-1992
    fn = max(0, 3.0 * (cr_eq - 0.93 * ni_eq - 6.4))
    return round(fn, 1)


def _describe_microstructure(f_m: float, f_b: float, f_fp: float,
                              delta_fn: Optional[float] = None) -> str:
    """Human-readable microstructure description (bilingual).
    可读的组织描述（双语）。"""
    if delta_fn is not None:
        if delta_fn < 3:
            return f"Austenite + trace delta-ferrite (FN={delta_fn}) / 奥氏体+微量δ铁素体"
        elif delta_fn < 10:
            return f"Austenite + delta-ferrite (FN={delta_fn}) / 奥氏体+δ铁素体"
        else:
            return f"Duplex austenite-ferrite (FN={delta_fn}) / 双相奥氏体-铁素体"
    if f_m > 0.9:
        return "Fully martensitic / 全马氏体"
    elif f_m > 0.5:
        return f"Predominantly martensitic with bainite ({f_m*100:.0f}%M+{f_b*100:.0f}%B) / 马氏体为主+贝氏体"
    elif f_b > 0.5:
        return f"Predominantly bainitic ({f_b*100:.0f}%B+{f_m*100:.0f}%M) / 贝氏体为主+马氏体"
    elif f_fp > 0.5:
        if f_b > 0.2:
            return f"Ferrite+pearlite with some bainite ({f_fp*100:.0f}%F+P+{f_b*100:.0f}%B) / 铁素体+珠光体+少量贝氏体"
        else:
            return "Ferrite + pearlite / 铁素体+珠光体"
    else:
        return f"Mixed: {f_m*100:.0f}%M + {f_b*100:.0f}%B + {f_fp*100:.0f}%F+P"


# ============================================================
# 4. Hardness Prediction / 硬度预测
# ============================================================

def predict_hardness(mat: MaterialSpec, f_m: float, f_b: float, f_fp: float,
                     t85: Optional[float] = None) -> float:
    """Predict Vickers hardness from phase fractions and composition.
    从组织比例和成分预测维氏硬度。

    Uses rule-of-mixtures with composition-dependent phase hardness.
    """
    c_pct = mat.composition.get("C", 0) * 100  # convert to wt%

    # Martensite hardness: strong function of carbon content
    # Maynier (1978): HV_m = 127 + 949*C + 27*Si + 11*Mn + 8*Ni + 16*Cr + 21*log(Vr)
    # Simplified for welding (Grong):
    hv_m = 300.0 + 1000.0 * mat.composition.get("C", 0)

    # Self-tempering effect: slower cooling allows some auto-tempering
    if t85 and t85 > 5:
        temper_factor = min(0.3, (t85 - 5) * 0.01)
        hv_m *= (1.0 - temper_factor)

    # Bainite hardness
    hv_b = 200.0 + 500.0 * mat.composition.get("C", 0)

    # Ferrite+pearlite hardness
    hv_fp = 100.0 + 250.0 * mat.composition.get("C", 0)

    # Rule of mixtures
    hv = f_m * hv_m + f_b * hv_b + f_fp * hv_fp

    return round(hv, 1)


def predict_hardness_direct(mat: MaterialSpec, t85: float) -> float:
    """Direct hardness prediction from t8/5 (convenience wrapper).
    从t8/5直接预测硬度（便捷封装）。"""
    phases = predict_phase_fractions(mat, t85)
    return predict_hardness(mat,
                            phases["martensite_fraction"],
                            phases["bainite_fraction"],
                            phases["ferrite_pearlite_fraction"],
                            t85)


# ============================================================
# 5. HAZ Sub-zone Model / 热影响区亚区模型
# ============================================================

def haz_zone_analysis(mat: MaterialSpec, t85_fusion_line: float,
                       peak_temps: List[dict],
                       base_preheat_C: float = 25.0) -> dict:
    """Analyze HAZ sub-zones: CGHAZ, FGHAZ, ICHAZ, SCHAZ.
    分析HAZ各亚区：粗晶区、细晶区、临界区、亚临界区。

    Args:
        mat: Material specification
        t85_fusion_line: t8/5 at fusion line (fastest cooling)
        peak_temps: List of {distance_mm, peak_temperature_C} from thermal model
        base_preheat_C: Preheat temperature

    Returns per-zone microstructure and hardness.
    """
    trans = critical_transformation_temperatures(mat)
    ac1 = trans["Ac1_C"]
    ac3 = trans["Ac3_C"]
    ms = trans["Ms_C"]

    zones = {}
    # Find the distance ranges for each HAZ zone
    # CGHAZ: peak T > ~1200 C (significantly above Ac3, grain growth)
    # FGHAZ: Ac3 < peak T < ~1200 C (full austenitization, fine grains)
    # ICHAZ: Ac1 < peak T < Ac3 (partial transformation)
    # SCHAZ: peak T < Ac1 (tempering only, no austenitization)

    # Get distances for each zone from peak temperature distribution
    cghaz_distances = []
    fghaz_distances = []
    ichaz_distances = []
    schaz_distances = []

    for pt in peak_temps:
        d = pt.get("distance_from_center_mm", 0)
        tp = pt.get("peak_temperature_C", 0)
        if tp > 1200:
            cghaz_distances.append(d)
        elif tp > ac3:
            fghaz_distances.append(d)
        elif tp > ac1:
            ichaz_distances.append(d)
        elif tp > base_preheat_C + 50:
            schaz_distances.append(d)

    def _zone_range(dists):
        if not dists:
            return None, None
        return round(min(dists), 2), round(max(dists), 2)

    # CGHAZ: fastest cooling, use t85_fusion_line
    cghaz_phases = predict_phase_fractions(mat, t85_fusion_line, 1350.0)
    cghaz_hv = predict_hardness(mat, cghaz_phases["martensite_fraction"],
                                 cghaz_phases["bainite_fraction"],
                                 cghaz_phases["ferrite_pearlite_fraction"],
                                 t85_fusion_line)
    cghaz_range = _zone_range(cghaz_distances)

    # FGHAZ: slower cooling than fusion line (~1.5-2x t8/5)
    fghaz_t85 = t85_fusion_line * 1.6
    fghaz_phases = predict_phase_fractions(mat, fghaz_t85, 1000.0)
    fghaz_hv = predict_hardness(mat, fghaz_phases["martensite_fraction"],
                                 fghaz_phases["bainite_fraction"],
                                 fghaz_phases["ferrite_pearlite_fraction"],
                                 fghaz_t85)
    fghaz_range = _zone_range(fghaz_distances)

    # ICHAZ: partial transformation, slower cooling (~3-5x t8/5)
    ichaz_t85 = t85_fusion_line * 4.0
    ichaz_phases = predict_phase_fractions(mat, ichaz_t85, 800.0)
    ichaz_hv = predict_hardness(mat, ichaz_phases["martensite_fraction"],
                                 ichaz_phases["bainite_fraction"],
                                 ichaz_phases["ferrite_pearlite_fraction"],
                                 ichaz_t85)
    ichaz_range = _zone_range(ichaz_distances)

    # SCHAZ: tempering only, slowest cooling (~8-10x t8/5)
    schaz_t85 = t85_fusion_line * 8.0
    # No austenitization → base metal microstructure with some tempering
    schaz_hv = predict_hardness_direct(mat, schaz_t85)
    schaz_range = _zone_range(schaz_distances)

    zones = {
        "CGHAZ": {
            "name": "Coarse Grain HAZ / 粗晶区",
            "peak_temp_C": "> 1200",
            "distance_range_mm": cghaz_range,
            "t85_effective_s": round(t85_fusion_line, 2),
            "phases": cghaz_phases,
            "hardness_HV": cghaz_hv,
            "risk_note": _cghaz_risk_note(mat, cghaz_hv, cghaz_phases),
        },
        "FGHAZ": {
            "name": "Fine Grain HAZ / 细晶区",
            "peak_temp_C": f"{ac3:.0f} - 1200",
            "distance_range_mm": fghaz_range,
            "t85_effective_s": round(fghaz_t85, 2),
            "phases": fghaz_phases,
            "hardness_HV": fghaz_hv,
        },
        "ICHAZ": {
            "name": "Intercritical HAZ / 临界区",
            "peak_temp_C": f"{ac1:.0f} - {ac3:.0f}",
            "distance_range_mm": ichaz_range,
            "t85_effective_s": round(ichaz_t85, 2),
            "phases": ichaz_phases,
            "hardness_HV": ichaz_hv,
        },
        "SCHAZ": {
            "name": "Subcritical HAZ / 亚临界区",
            "peak_temp_C": f"{base_preheat_C + 50:.0f} - {ac1:.0f}",
            "distance_range_mm": schaz_range,
            "t85_effective_s": round(schaz_t85, 2),
            "hardness_HV": schaz_hv,
            "effect": "Tempering only, no phase transformation / 仅回火，无相变",
        },
    }

    return zones


def _cghaz_risk_note(mat: MaterialSpec, hv: float, phases: dict) -> str:
    """Risk assessment note for CGHAZ.
    CGHAZ风险评估。"""
    notes = []
    if hv > 380:
        notes.append("High hardness: cold cracking risk / 高硬度：冷裂纹风险")
    elif hv > 300:
        notes.append("Elevated hardness: monitor hydrogen / 硬度偏高：注意控氢")
    if phases.get("martensite_fraction", 0) > 0.9:
        notes.append("Fully hardened: PWHT recommended / 完全淬硬：建议焊后热处理")
    return "; ".join(notes) if notes else "Acceptable / 可接受"


# ============================================================
# 6. Hardness Distribution Across Weld / 焊缝截面硬度分布
# ============================================================

def hardness_distribution(mat: MaterialSpec, t85_fusion_line: float,
                           peak_temps: List[dict],
                           base_hardness_HV: Optional[float] = None) -> List[dict]:
    """Compute hardness at each distance point across the HAZ.
    计算HAZ各距离点的硬度分布。

    Args:
        mat: Material specification
        t85_fusion_line: t8/5 at the fusion line
        peak_temps: List of {distance_mm, peak_temperature_C}
        base_hardness_HV: Base metal hardness. If None, estimated from composition.

    Returns list of {distance_mm, peak_temp_C, t85_effective_s, hardness_HV, phase_fractions}
    """
    if base_hardness_HV is None:
        # Estimate base hardness from ferrite+pearlite formula
        base_hardness_HV = 100.0 + 250.0 * mat.composition.get("C", 0)

    # Find fusion line peak temperature for scaling
    t_peak_max = max((pt.get("peak_temperature_C", 0) for pt in peak_temps), default=1500)
    if t_peak_max < 1:
        t_peak_max = 1500

    results = []
    for pt in peak_temps:
        d = pt.get("distance_from_center_mm", 0)
        tp = pt.get("peak_temperature_C", 0)

        # Scale t8/5 based on peak temperature
        # Cooling rate ∝ (T_peak - T_0)^n where n depends on heat flow
        # Approximate: t8/5 ∝ (T_peak/T_peak_max)^(-2.5)
        if tp > 100 and t_peak_max > 100:
            t85_ratio = (t_peak_max / tp) ** 2.5
        else:
            t85_ratio = 20.0

        t85_eff = t85_fusion_line * t85_ratio
        t85_eff = min(t85_eff, 200.0)  # cap at 200s

        # Predict phases and hardness
        phases = predict_phase_fractions(mat, t85_eff, tp)
        hv = predict_hardness(mat,
                              phases["martensite_fraction"],
                              phases["bainite_fraction"],
                              phases["ferrite_pearlite_fraction"],
                              t85_eff)

        results.append({
            "distance_from_center_mm": round(d, 1),
            "peak_temperature_C": round(tp, 1),
            "t85_effective_s": round(t85_eff, 2),
            "hardness_HV": hv,
            "martensite_fraction": phases["martensite_fraction"],
            "bainite_fraction": phases["bainite_fraction"],
            "ferrite_pearlite_fraction": phases["ferrite_pearlite_fraction"],
        })

    # Add base metal reference at the end
    if results:
        last_d = results[-1]["distance_from_center_mm"] + 5
        results.append({
            "distance_from_center_mm": round(last_d, 1),
            "peak_temperature_C": round(mat.composition.get("C", 0) * 100 + 25, 1),
            "t85_effective_s": 999,
            "hardness_HV": round(base_hardness_HV, 1),
            "martensite_fraction": 0.0,
            "bainite_fraction": 0.0,
            "ferrite_pearlite_fraction": 1.0,
        })

    return results


# ============================================================
# 7. Full Metallurgical Analysis / 完整金相分析
# ============================================================

def full_metallurgical_analysis(mat: MaterialSpec, t85: float,
                                 peak_temps: List[dict],
                                 preheat_C: float = 25.0) -> dict:
    """Complete metallurgical analysis: all sub-models combined.
    完整金相分析：所有子模型合并输出。

    This is the primary entry point for integration into the analysis pipeline.
    这是集成到分析管线的主要入口。
    """
    is_stainless = mat.composition.get("Cr", 0) > 10
    is_nickel = mat.composition.get("Ni", 0) > 30
    is_titanium = mat.composition.get("Ti", 0) > 50
    is_aluminium = mat.density < 5000 and not is_titanium

    if is_titanium or is_aluminium:
        # Ti/Al have different metallurgy — skip CCT-based prediction
        return {
            "material_type": "titanium" if is_titanium else "aluminium",
            "note": "Ti/Al metallurgy requires different modeling approach. "
                    "Phase 2 will add Ti α/β colony prediction and Al aging response.",
            "note_cn": "钛/铝合金需要不同的建模方法。Phase 2将添加钛α/β集束预测和铝时效响应。",
        }

    if is_nickel:
        return {
            "material_type": "nickel",
            "note": "Ni-based superalloys: γ' precipitation and solidification cracking are primary concerns. "
                    "Standard CCT-based prediction not applicable.",
            "note_cn": "镍基高温合金：γ'相析出和凝固裂纹是主要关注点。标准CCT预测不适用。",
            "delta_ferrite_FN": _delta_ferrite_wrc1992(mat) if mat.composition.get("Cr", 0) > 10 else None,
        }

    trans = critical_transformation_temperatures(mat)
    crit = critical_cooling_times(mat)
    fusion_phases = predict_phase_fractions(mat, t85)
    fusion_hv = predict_hardness(mat, fusion_phases["martensite_fraction"],
                                  fusion_phases["bainite_fraction"],
                                  fusion_phases["ferrite_pearlite_fraction"], t85)
    haz_zones = haz_zone_analysis(mat, t85, peak_temps, preheat_C)
    hardness_dist = hardness_distribution(mat, t85, peak_temps)

    result = {
        "material_type": "stainless" if is_stainless else "carbon_steel",
        "transformation_temperatures": trans,
        "critical_cooling_times": crit,
        "fusion_line": {
            "t85_s": round(t85, 2),
            "phases": fusion_phases,
            "hardness_HV": fusion_hv,
        },
        "haz_zones": haz_zones,
        "hardness_distribution": hardness_dist,
        "max_hardness_HV": max((h["hardness_HV"] for h in hardness_dist), default=0),
        "recommendations": _metallurgy_recommendations(mat, t85, fusion_hv, fusion_phases),
    }

    return result


def _metallurgy_recommendations(mat: MaterialSpec, t85: float,
                                 hv: float, phases: dict) -> List[str]:
    """Generate metallurgy-specific recommendations.
    生成金相学相关建议。"""
    recs = []
    if hv > 380:
        recs.append(f"CGHAZ hardness {hv:.0f} HV exceeds typical limit (350 HV). "
                     "Increase preheat or use PWHT. / CGHAZ硬度{hv:.0f}HV超限，建议提高预热或焊后热处理。")
    if phases.get("martensite_fraction", 0) > 0.8:
        recs.append("> 80% martensite predicted. Cold cracking risk is high. "
                     "Use low-hydrogen process and immediate PWHT. / 预测>80%马氏体，冷裂纹风险高。使用低氢工艺并立即热处理。")
    if t85 < 3:
        recs.append(f"t8/5 = {t85:.1f}s is critically fast. "
                     f"Increase heat input or preheat to > {mat.composition.get('C',0)*1000+100:.0f} C. "
                     f"/ t8/5={t85:.1f}s极快，需提高热输入或预热。")
    if not recs:
        recs.append("Microstructure within acceptable range. / 组织在可接受范围内。")
    return recs
