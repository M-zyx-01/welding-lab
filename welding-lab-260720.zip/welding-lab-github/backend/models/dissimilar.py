"""
Dissimilar metal welding: Schaeffler/WRC diagrams, dilution, transition zone prediction.
异种金属焊接：Schaeffler/WRC图、稀释率、过渡层预测、电偶腐蚀修正。
"""
import math
from typing import Optional, Dict, List
from ..data.weld_data import MaterialSpec


def schaeffler_diagram(base: MaterialSpec, filler: MaterialSpec,
                        dilution_pct: float = 30.0) -> dict:
    """Schaeffler diagram: predict weld metal microstructure for dissimilar joints.
    Schaeffler图：预测异种接头焊缝金属组织。

    Cr_eq = Cr + Mo + 1.5*Si + 0.5*Nb
    Ni_eq = Ni + 30*C + 0.5*Mn

    Dilution: D% = A_base / (A_base + A_filler) × 100
    Weld metal composition = D% × base + (1-D%) × filler
    """
    def _cr_eq(m):
        c = m.composition
        return c.get("Cr", 0) + c.get("Mo", 0) + 1.5 * c.get("Si", 0) + 0.5 * c.get("Nb", 0)

    def _ni_eq(m):
        c = m.composition
        return c.get("Ni", 0) + 30.0 * c.get("C", 0) + 0.5 * c.get("Mn", 0) + 0.5 * c.get("Cu", 0)

    # Base metal
    cr_b = _cr_eq(base)
    ni_b = _ni_eq(base)
    # Filler
    cr_f = _cr_eq(filler)
    ni_f = _ni_eq(filler)
    # Diluted composition
    d_frac = dilution_pct / 100.0
    cr_weld = d_frac * cr_b + (1.0 - d_frac) * cr_f
    ni_weld = d_frac * ni_b + (1.0 - d_frac) * ni_f

    # Phase classification on Schaeffler
    phase = _schaeffler_phase(cr_weld, ni_weld)
    # Delta ferrite from Schaeffler
    fn_schaeffler = _schaeffler_fn(cr_weld, ni_weld)

    return {
        "diagram": "Schaeffler / Schaeffler图",
        "base_metal": {"Cr_eq": round(cr_b, 1), "Ni_eq": round(ni_b, 1)},
        "filler_metal": {"Cr_eq": round(cr_f, 1), "Ni_eq": round(ni_f, 1)},
        "weld_metal_diluted": {"Cr_eq": round(cr_weld, 1), "Ni_eq": round(ni_weld, 1)},
        "dilution_pct": dilution_pct,
        "predicted_phase": phase["phase"],
        "predicted_phase_cn": phase["phase_cn"],
        "delta_ferrite_FN": round(fn_schaeffler, 1),
        "cracking_risk": phase["risk"],
        "cracking_risk_cn": phase["risk_cn"],
    }


def _schaeffler_phase(cr_eq: float, ni_eq: float) -> dict:
    """Classify microstructure based on Schaeffler diagram coordinates.
    基于Schaeffler图坐标分类组织。"""
    if ni_eq < 5:
        if cr_eq < 10:
            return {"phase": "Martensite", "phase_cn": "马氏体",
                    "risk": "High cold cracking", "risk_cn": "冷裂纹风险高"}
        elif cr_eq < 17:
            return {"phase": "Martensite + Ferrite", "phase_cn": "马氏体+铁素体",
                    "risk": "Moderate cold cracking", "risk_cn": "冷裂纹风险中等"}
        else:
            return {"phase": "Ferrite", "phase_cn": "铁素体",
                    "risk": "Grain growth/embrittlement", "risk_cn": "晶粒长大/脆化"}
    elif ni_eq < 14:
        if cr_eq < 17:
            return {"phase": "Martensite", "phase_cn": "马氏体",
                    "risk": "High cold cracking", "risk_cn": "冷裂纹风险高"}
        elif cr_eq < 22:
            return {"phase": "Austenite + Martensite", "phase_cn": "奥氏体+马氏体",
                    "risk": "Moderate", "risk_cn": "中等"}
        elif cr_eq < 30:
            return {"phase": "Austenite + Ferrite", "phase_cn": "奥氏体+铁素体",
                    "risk": "Low (if 3-10% FN)", "risk_cn": "低（FN 3-10%时）"}
        else:
            return {"phase": "Austenite + Ferrite (high FN)", "phase_cn": "奥氏体+铁素体(FN偏高)",
                    "risk": "Sigma phase at high temp", "risk_cn": "高温σ相风险"}
    else:
        if cr_eq < 20:
            return {"phase": "Austenite", "phase_cn": "奥氏体",
                    "risk": "Hot cracking (if fully A)", "risk_cn": "热裂纹（全奥氏体时）"}
        elif cr_eq < 30:
            return {"phase": "Austenite + Ferrite (optimal)", "phase_cn": "奥氏体+铁素体(最佳)",
                    "risk": "Low", "risk_cn": "低"}
        else:
            return {"phase": "Austenite + Ferrite", "phase_cn": "奥氏体+铁素体",
                    "risk": "Low-Moderate", "risk_cn": "低到中等"}


def _schaeffler_fn(cr_eq: float, ni_eq: float) -> float:
    """Delta ferrite number from Schaeffler diagram.
    Schaeffler图δ铁素体含量。"""
    # Simple linear approximation: FN ≈ 3 * (Cr_eq - 0.93 * Ni_eq - 6.4)
    fn = 3.0 * (cr_eq - 0.93 * ni_eq - 6.4)
    return max(0.0, round(fn, 1))


def wrc1992_diagram(base: MaterialSpec, filler: MaterialSpec,
                     dilution_pct: float = 30.0) -> dict:
    """WRC-1992 diagram: higher accuracy for stainless steels.
    WRC-1992图：不锈钢更高精度预测。

    Cr_eq = Cr + Mo + 0.7×Nb
    Ni_eq = Ni + 35×C + 20×N + 0.25×Cu
    """
    def _cr_eq(m):
        c = m.composition
        return c.get("Cr", 0) + c.get("Mo", 0) + 0.7 * c.get("Nb", 0)

    def _ni_eq(m):
        c = m.composition
        return c.get("Ni", 0) + 35.0 * c.get("C", 0) + 20.0 * c.get("N", 0) + 0.25 * c.get("Cu", 0)

    cr_b = _cr_eq(base)
    ni_b = _ni_eq(base)
    cr_f = _cr_eq(filler)
    ni_f = _ni_eq(filler)
    d_frac = dilution_pct / 100.0
    cr_weld = d_frac * cr_b + (1.0 - d_frac) * cr_f
    ni_weld = d_frac * ni_b + (1.0 - d_frac) * ni_f
    fn = 3.0 * (cr_weld - 0.93 * ni_weld - 6.4)
    fn = max(0.0, round(fn, 1))
    # Solidification mode from WRC-1992
    if cr_weld / ni_weld > 2.0:
        solid_mode = "F (ferrite primary) / 铁素体初晶"
    elif cr_weld / ni_weld > 1.5:
        solid_mode = "FA (ferrite-austenite) / 铁素体-奥氏体"
    elif cr_weld / ni_weld > 1.3:
        solid_mode = "AF (austenite-ferrite) / 奥氏体-铁素体"
    else:
        solid_mode = "A (austenite) / 奥氏体"
    return {
        "diagram": "WRC-1992 / WRC-1992图",
        "base_metal": {"Cr_eq": round(cr_b, 1), "Ni_eq": round(ni_b, 1)},
        "filler_metal": {"Cr_eq": round(cr_f, 1), "Ni_eq": round(ni_f, 1)},
        "weld_metal_diluted": {"Cr_eq": round(cr_weld, 1), "Ni_eq": round(ni_weld, 1)},
        "dilution_pct": dilution_pct,
        "delta_ferrite_FN": fn,
        "solidification_mode": solid_mode,
        "hot_cracking_risk": ("Low" if 3 <= fn <= 15 else
                               "Moderate (low FN)" if 0 < fn < 3 else
                               "High (fully austenitic)" if fn == 0 else
                               "Moderate (high FN, sigma phase risk)"),
    }


def dilution_rate(params, joint) -> dict:
    """Estimate dilution rate based on weld pool geometry.
    基于熔池几何估计稀释率。"""
    # Dilution ≈ area of base metal melted / total weld pool area
    # For butt joints: depends on groove angle and root face
    # Approximate formula for V-groove butt joint
    if joint.groove_type == "V":
        base_dil = 30.0  # V-groove typical: 25-35%
    elif joint.groove_type == "U":
        base_dil = 25.0
    elif joint.groove_type == "square":
        base_dil = 40.0  # Square butt: more dilution
    else:
        base_dil = 30.0
    # Adjust for plate thickness (thinner = more dilution)
    if joint.plate_thickness < 6:
        base_dil += 10
    elif joint.plate_thickness > 25:
        base_dil -= 10
    # Adjust for heat input
    # Higher heat input → deeper penetration → more dilution
    base_dil = max(10.0, min(70.0, base_dil))
    return {
        "estimated_dilution_pct": round(base_dil, 1),
        "low_estimate_pct": round(base_dil - 10, 1),
        "high_estimate_pct": round(base_dil + 10, 1),
    }


def galvanic_correction(base: MaterialSpec, filler: MaterialSpec) -> dict:
    """Galvanic corrosion risk for dissimilar metal couples.
    异种金属电偶腐蚀风险评估。"""
    # Simplified galvanic series potentials (V vs SCE)
    # More negative = more anodic = corrodes preferentially
    potentials = {
        "magnesium": -1.6, "aluminium": -0.85, "titanium": -0.15,
        "carbon_steel": -0.60, "stainless_304": -0.25, "stainless_316": -0.15,
        "copper": -0.20, "nickel": -0.15, "monel": -0.15,
        "inconel": -0.10, "hastelloy": -0.05, "graphite": 0.3,
    }

    def _classify(m):
        c = m.composition
        if c.get("Ti", 0) > 50:
            return "titanium"
        if m.density < 5000:
            return "aluminium"
        if c.get("Cu", 0) > 50:
            return "copper"
        if c.get("Ni", 0) > 30:
            if c.get("Mo", 0) > 10:
                return "hastelloy"
            return "inconel" if c.get("Cr", 0) > 15 else "monel"
        if c.get("Cr", 0) > 15:
            return "stainless_316" if c.get("Mo", 0) > 2 else "stainless_304"
        return "carbon_steel"

    base_type = _classify(base)
    filler_type = _classify(filler)
    e_base = potentials.get(base_type, -0.5)
    e_filler = potentials.get(filler_type, -0.5)
    delta_e = abs(e_base - e_filler)

    if delta_e < 0.15:
        risk = "Low / 低"
        note = "Minimal galvanic coupling. Joint safe without isolation."
        note_cn = "电偶耦合极小，无需隔离。"
    elif delta_e < 0.40:
        risk = "Moderate / 中等"
        note = "Moderate galvanic risk. Consider coating or insulation at joint."
        note_cn = "中等电偶风险，建议接头处涂装或绝缘。"
    else:
        risk = "High / 高"
        note = "Severe galvanic corrosion risk. Use transition piece, coating, or cathodic protection."
        note_cn = "严重电偶腐蚀风险，需使用过渡接头、涂层或阴极保护。"

    return {
        "base_material_type": base_type,
        "filler_material_type": filler_type,
        "base_potential_V": e_base,
        "filler_potential_V": e_filler,
        "potential_difference_V": round(delta_e, 2),
        "galvanic_risk": risk,
        "note": note,
        "note_cn": note_cn,
        "anode": base_type if e_base < e_filler else filler_type,
    }


def full_dissimilar_analysis(base: MaterialSpec, filler: MaterialSpec,
                              joint=None) -> dict:
    """Complete dissimilar metal welding analysis.
    完整异种金属焊接分析。"""
    # Check if actually dissimilar
    base_has_cr = base.composition.get("Cr", 0) > 10
    filler_has_cr = filler.composition.get("Cr", 0) > 10
    is_stainless_pair = base_has_cr or filler_has_cr
    # Estimate dilution
    dil_pct = 30.0
    if joint:
        dil = dilution_rate(None, joint)
        dil_pct = dil["estimated_dilution_pct"]
    # Schaeffler analysis
    sch_result = schaeffler_diagram(base, filler, dil_pct)
    # WRC-1992 if stainless involved
    wrc_result = wrc1992_diagram(base, filler, dil_pct) if is_stainless_pair else None
    # Galvanic
    galv_result = galvanic_correction(base, filler)
    # Transition zone prediction
    transition = _transition_zone_prediction(base, filler, dil_pct)
    return {
        "is_dissimilar": True,
        "base_material": base.name,
        "filler_material": filler.name,
        "schaeffler": sch_result,
        "wrc_1992": wrc_result,
        "galvanic": galv_result,
        "transition_zone": transition,
    }


def _transition_zone_prediction(base: MaterialSpec, filler: MaterialSpec,
                                 dilution_pct: float) -> dict:
    """Predict transition zone microstructure.
    预测过渡层组织。"""
    # Three zones: base side, center, filler side
    # Each has different dilution levels
    zones = []
    for name, dil in [("Base side / 母材侧", 60), ("Center / 中心", dilution_pct), ("Filler side / 焊材侧", 10)]:
        sch = schaeffler_diagram(base, filler, dil)
        zones.append({
            "zone": name,
            "dilution_pct": dil,
            "phase": sch["predicted_phase"],
            "phase_cn": sch["predicted_phase_cn"],
            "delta_ferrite_FN": sch["delta_ferrite_FN"],
        })
    # Carbon migration risk
    c_base = base.composition.get("C", 0)
    c_filler = filler.composition.get("C", 0)
    c_diff = abs(c_base - c_filler)
    if c_diff > 0.1:
        migration = "High: carbon migration expected. Decarburized zone in base, carburized zone in filler. / 高：预期碳迁移。母材脱碳层+焊材渗碳层。"
    elif c_diff > 0.03:
        migration = "Moderate / 中等"
    else:
        migration = "Low / 低"
    return {
        "zones": zones,
        "carbon_migration_risk": migration,
        "carbon_diff_pct": round(c_diff * 100, 2),
    }
