"""
Multi-pass welding: thermal accumulation, reheat cracking, temper bead effects.
多道焊分析：道间热累积、再热裂纹、回火焊道效应。
"""
import math
from typing import List, Optional, Dict
from ..data.weld_data import WeldParameters, MaterialSpec, WeldJoint


def interpass_thermal_decay(params: WeldParameters, mat: MaterialSpec,
                             joint: WeldJoint,
                             time_between_passes_s: float = 120.0) -> dict:
    """Predict interpass temperature decay after a pass.
    预测焊道间的温度衰减。

    Uses lumped-capacitance model for plate cooling.
    τ = d² × ρ × Cp / k  (thick plate) or  τ = d² × ρ × Cp / (4k)  (thin plate)
    """
    d_mm = joint.plate_thickness
    d_m = d_mm / 1000.0
    k = mat.thermal_conductivity
    rho = mat.density
    Cp = mat.specific_heat
    # Thermal time constant
    # Thin plate (< 15 mm): 2D heat flow, faster cooling
    if d_mm < 15:
        tau = (d_m ** 2) * rho * Cp / (4.0 * k)
    else:
        tau = (d_m ** 2) * rho * Cp / k
    tau = max(tau, 1.0)
    # Peak temperature at fusion zone
    T_peak = mat.melting_point
    T_ambient = params.preheat_temp
    # Temperature after time t (exponential decay)
    decay_factors = []
    for t in [30, 60, 120, 180, 300]:  # 30s, 1min, 2min, 3min, 5min
        T_t = T_ambient + (T_peak - T_ambient) * math.exp(-t / tau)
        decay_factors.append({
            "time_s": t, "temperature_C": round(T_t, 1),
            "above_preheat_C": round(T_t - T_ambient, 1),
        })
    # Effective interpass temperature after typical wait
    T_interpass = T_ambient + (T_peak - T_ambient) * math.exp(-time_between_passes_s / tau)
    T_interpass = max(T_ambient, min(T_interpass, params.interpass_temp))
    return {
        "thermal_time_constant_s": round(tau, 1),
        "initial_peak_C": round(T_peak, 1),
        "preheat_C": round(T_ambient, 1),
        "interpass_time_s": time_between_passes_s,
        "effective_interpass_temp_C": round(T_interpass, 1),
        "decay_curve": decay_factors,
        "note": ("Thin plate (2D) / 薄板" if d_mm < 15 else "Thick plate (3D) / 厚板"),
    }


def pass_thermal_history(params: WeldParameters, mat: MaterialSpec,
                          joint: WeldJoint,
                          time_between_passes_s: float = 120.0) -> dict:
    """Simulate thermal history across multiple passes.
    模拟多道焊的热历史。

    Models the t8/5 evolution as subsequent passes modify the effective preheat.
    """
    n_passes = joint.number_of_passes
    if n_passes < 2:
        return {"single_pass": True, "note": "Single pass only / 单道焊"}
    decay = interpass_thermal_decay(params, mat, joint, time_between_passes_s)
    T_interpass = decay["effective_interpass_temp_C"]
    # Each pass: effective preheat = previous pass residual heat
    # t8/5 proportional to heat input and inversely proportional to (T_peak - T_eff)^2
    # Simplified: each subsequent pass has +5-10% higher t8/5 due to heat buildup
    passes = []
    T_base = params.preheat_temp
    for i in range(n_passes):
        # Effective preheat increases with each pass
        if i == 0:
            T_eff = T_base
        else:
            # After first pass, effective preheat is interpass temp
            # Gradually increases: T_eff(n) = T_base + n/(n_passes) * (T_interpass - T_base)
            T_eff = T_base + (i / n_passes) * (T_interpass - T_base)
            T_eff = min(T_eff, params.interpass_temp)
        # t8/5 increase factor from elevated preheat
        # For 2D heat flow, t8/5 ∝ 1/(T - T_eff)² approximately
        T_peak_K = mat.melting_point + 273.15
        T_eff_K = T_eff + 273.15
        T_base_K = T_base + 273.15
        if T_base_K < T_peak_K - 100:
            t85_factor = ((T_peak_K - T_base_K) / (T_peak_K - T_eff_K)) ** 2
        else:
            t85_factor = 1.0
        t85_factor = min(t85_factor, 3.0)  # Cap at 3x
        passes.append({
            "pass_number": i + 1,
            "effective_preheat_C": round(T_eff, 1),
            "t85_multiplier": round(t85_factor, 2),
            "cumulative_heat": "Base / 基准" if i == 0 else f"+{(t85_factor-1)*100:.0f}% / 热累积",
        })
    # Maximum interpass temperature check
    max_interpass_allowed = params.interpass_temp
    overheat_risk = T_interpass > max_interpass_allowed
    return {
        "single_pass": False,
        "number_of_passes": n_passes,
        "interpass_time_s": time_between_passes_s,
        "final_interpass_temp_C": round(T_interpass, 1),
        "max_allowed_interpass_C": max_interpass_allowed,
        "overheat_risk": overheat_risk,
        "overheat_note": ("Interpass temp exceeds limit / 层间温度超限" if overheat_risk else
                          "Within limits / 温度受控"),
        "pass_history": passes,
    }


def reheat_cracking_risk(mat: MaterialSpec) -> dict:
    """Assess reheat cracking (stress-relief cracking) susceptibility.
    评估再热裂纹（消除应力裂纹）敏感性。

    Reheat cracking occurs during PWHT or multi-pass welding when
    previously deposited weld metal is heated to 550-700 C.

    PSR formula: PSR = Cr% + Cu% + 2×Mo% + 10×V% + 7×Nb% + 5×Ti% - 2
    If PSR > 0: susceptible
    """
    c = mat.composition
    psr = (c.get("Cr", 0) + c.get("Cu", 0) + 2.0 * c.get("Mo", 0)
           + 10.0 * c.get("V", 0) + 7.0 * c.get("Nb", 0)
           + 5.0 * c.get("Ti", 0) - 2.0)
    if psr > 2:
        risk = "Severe / 严重"
        detail = "High susceptibility to reheat cracking. PWHT at T < 550 C or use low-Cr filler."
        detail_cn = "再热裂纹高度敏感。焊后热处理温度控制在550C以下，或使用低Cr焊材。"
    elif psr > 0:
        risk = "Moderate / 中等"
        detail = "Moderate susceptibility. Control heating rate during PWHT to < 50 C/h through 550-700 C."
        detail_cn = "中等敏感。焊后热处理时在550-700C区间升温速率控制<50C/h。"
    else:
        risk = "Low / 低"
        detail = "Low reheat cracking susceptibility. Standard PWHT acceptable."
        detail_cn = "再热裂纹敏感性低。标准焊后热处理可行。"
    susceptible_elements = []
    if c.get("Cr", 0) > 1:
        susceptible_elements.append(f"Cr={c['Cr']:.1f}%")
    if c.get("Mo", 0) > 0.5:
        susceptible_elements.append(f"Mo={c['Mo']:.1f}%")
    if c.get("V", 0) > 0.05:
        susceptible_elements.append(f"V={c['V']:.3f}%")
    if c.get("Nb", 0) > 0.02:
        susceptible_elements.append(f"Nb={c['Nb']:.3f}%")
    return {
        "PSR_value": round(psr, 2),
        "risk_level": risk,
        "detail": detail,
        "detail_cn": detail_cn,
        "susceptible_elements": susceptible_elements,
        "critical_temp_range": "550-700 C",
    }


def temper_bead_effect(mat: MaterialSpec, n_passes: int) -> dict:
    """Predict tempering effect of subsequent passes on previous HAZ.
    预测后续焊道对前一道HAZ的回火效应。

    When a subsequent pass heats previous HAZ into tempering range
    (~Ac1 to ~650 C), hardness decreases. The effect is cumulative.
    """
    if n_passes < 2:
        return {"temper_effect": False, "note": "Single pass / 单道焊"}
    # Tempering hardness reduction per pass in the overlap zone
    # Martensite tempering: ~15-30% HV reduction when reheated to 550-700 C
    # Each additional pass provides some tempering
    temper_passes = n_passes - 1  # number of tempering events
    # Each tempering pass reduces hardness by decreasing amounts
    total_reduction = 0.0
    contributions = []
    for i in range(temper_passes):
        # Diminishing returns: first temper most effective
        reduction_i = 0.18 * (0.7 ** i)  # 18%, 12.6%, 8.8%, ...
        total_reduction += reduction_i
        contributions.append({
            "temper_pass": i + 1,
            "hardness_reduction_pct": round(reduction_i * 100, 1),
        })
    total_reduction = min(total_reduction, 0.45)
    # Only applies if HAZ is martensitic (for non-martensitic, effect is minimal)
    c = mat.composition.get("C", 0)
    if c < 0.05:
        total_reduction = total_reduction * 0.3  # Low C → minimal tempering effect
    return {
        "temper_effect": True,
        "temper_passes": temper_passes,
        "total_hardness_reduction_pct": round(total_reduction * 100, 1),
        "per_pass_contributions": contributions,
        "note": (f"Cumulative {total_reduction*100:.0f}% HV reduction across {temper_passes} tempering passes. "
                 f"/ 经{temper_passes}道回火焊道，累计硬度降低约{total_reduction*100:.0f}%。"),
    }


def full_multi_pass_analysis(params: WeldParameters, mat: MaterialSpec,
                              joint: WeldJoint,
                              time_between_passes_s: float = 120.0) -> dict:
    """Complete multi-pass welding analysis.
    完整多道焊分析。
    """
    thermal = pass_thermal_history(params, mat, joint, time_between_passes_s)
    reheat = reheat_cracking_risk(mat)
    temper = temper_bead_effect(mat, joint.number_of_passes)
    return {
        "number_of_passes": joint.number_of_passes,
        "thermal_history": thermal,
        "reheat_cracking": reheat,
        "temper_bead": temper,
    }
